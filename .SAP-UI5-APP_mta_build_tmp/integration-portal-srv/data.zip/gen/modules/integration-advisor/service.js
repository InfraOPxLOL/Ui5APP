import { emptyPage } from "../../core/http/pagination.js";
/**
 * Service for the Integration Advisor module. The only layer that talks to CPI (via the shared
 * {@link IntegrationSuiteClient}). It maps raw CPI payloads into the module DTOs so no upstream
 * shape leaks upward. Phase 1 methods return typed placeholder results.
 */
export class IntegrationAdvisorService {
    /**
     * Retrieves a server-paginated page of Integration Advisor rows.
     * @param query validated paging/sorting/filtering parameters.
     * @returns a page of rows (Phase 1: empty).
     */
    async list(query = {}) {
        return Promise.resolve(emptyPage(query.$top));
    }
}
/** Shared service instance. */
export const integrationAdvisorService = new IntegrationAdvisorService();
//# sourceMappingURL=service.js.map