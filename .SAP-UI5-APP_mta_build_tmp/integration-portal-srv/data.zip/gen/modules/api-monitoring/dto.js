/**
 * Data transfer objects for the API Monitoring module. These are the platform's stable shapes; the
 * service maps raw CPI payloads into them so no upstream shape leaks past the service layer.
 */
export {};
//# sourceMappingURL=dto.js.map