/**
 * Data transfer objects for the Dashboard module.
 */
export {};
//# sourceMappingURL=dto.js.map