import { createOperationsEngine } from "../../config/operationsEngineFactory.js";
/** Mock-engine settings used when the Operations Engine runs against the mock providers. */
const MOCK_CONFIG = { enabled: true, defaultScenario: "success" };
const DEFAULT_HISTORY_TOP = 50;
/**
 * Aggregation service for the Recovery Center (Phase 11). Builds a fresh, request-scoped
 * {@link OperationsEngine} per call (matching every other Operations-Engine-consuming module) and
 * delegates entirely to `engine.recovery` — this service adds no business logic of its own, only the
 * HTTP-facing seam (deriving `operator` from the caller's identity, defaulting pagination).
 *
 * Recovery History and queue growth-trend samples live in `RecoveryStateStore`'s process-lifetime
 * singleton (see its own doc comment), so they survive across the many short-lived engines this
 * service constructs — cancelling or retrying a recovery recorded by an earlier request works
 * correctly because every engine instance defaults to the *same* underlying store.
 */
export class RecoveryCenterService {
    engineFactory;
    constructor(engineFactory = () => createOperationsEngine(MOCK_CONFIG)) {
        this.engineFactory = engineFactory;
    }
    async getDashboard() {
        return this.engineFactory().recovery.getDashboard();
    }
    async listCandidates() {
        return this.engineFactory().recovery.listCandidates();
    }
    async getQueueHealth() {
        return this.engineFactory().recovery.getQueueHealth();
    }
    async getDlqOverview() {
        return this.engineFactory().recovery.getDlqOverview();
    }
    async getStatistics() {
        return this.engineFactory().recovery.getStatistics();
    }
    async validate(sourceQueue, callerHasOperatorScope) {
        return this.engineFactory().recovery.validateRecovery(sourceQueue, callerHasOperatorScope);
    }
    async preview(sourceQueue, callerHasOperatorScope) {
        return this.engineFactory().recovery.previewRecovery(sourceQueue, callerHasOperatorScope);
    }
    async recover(sourceQueue, body, operator, callerHasOperatorScope) {
        return this.engineFactory().recovery.executeRecovery({
            sourceQueue,
            messageIds: body.messageIds,
            dryRun: body.dryRun,
            operator,
            reason: body.reason,
        }, callerHasOperatorScope);
    }
    cancel(recoveryId) {
        return this.engineFactory().recovery.cancelRecovery(recoveryId);
    }
    async retry(recoveryId, callerHasOperatorScope) {
        return this.engineFactory().recovery.retryRecovery(recoveryId, callerHasOperatorScope);
    }
    getHistory(skip = 0, top = DEFAULT_HISTORY_TOP) {
        return this.engineFactory().recovery.getHistory({ skip, top });
    }
}
/** Shared service instance. */
export const recoveryCenterService = new RecoveryCenterService();
//# sourceMappingURL=service.js.map