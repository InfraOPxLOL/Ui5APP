/**
 * Data transfer objects for the CoE Route Wizard module (spec §4/§5 — "Create JMS + Common Router
 * Connection"). Every shape is composed from the Operations Engine's Partner Directory engine; the
 * module never leaks an SDK/CPI/OData shape.
 *
 * Partner Directory model (confirmed against the live tenant, corrected against user feedback):
 * - An **agreement** is a string parameter under the fixed registry PID `_Maintain_JMS_Agreements`
 *   (JMS) or `_Maintain_Router_Agreements` (Common Router): id `.{SNDPRN}.{RCVPRN}` (standard) or
 *   `.{MESTYP}.{SNDPRN}.{RCVPRN}` (specific); its **value is the target Partner ID** directly — this
 *   value *is* what earlier drafts wrongly duplicated into a separate `Target_PID` parameter; there is
 *   no such parameter.
 * - The **route key** is the 6-part `.{IDOCTYP}.{MESTYP}.{SNDPOR}.{SNDPRN}.{RCVPOR}.{RCVPRN}`, with
 *   `*` substituted for any part absent/unparsable in the EDI_DC40 control record.
 * - Under the **target PID**, `QUEUE_JMS_{routeKey}` holds the queue name and `ROUTE_JMS_{routeKey}`
 *   the endpoint URI, both directly (one hop each) — this is also where the JMS side's "final
 *   endpoint" lives; the Common Router side has no separate endpoint parameter of its own.
 * - Under a Common Router package PID, `ROUTE_{routeKey}` holds the final receiving Partner ID
 *   directly (one hop) — no `X-Route-Key`/`Clean_Route_Key` indirection.
 *
 * **Ruleset escalation** (a sender/receiver pair legitimately routes to more than one target — spec
 * §4 Step 2 "shared partner context"): the plain `.{SNDPRN}.{RCVPRN}` agreement is deleted and
 * replaced with `RULESET_.{SNDPRN}.{RCVPRN}` holding a comma-separated list of every candidate target
 * PID sharing the pair. Once a pair has been escalated this way it *stays* a ruleset (the plain key
 * never comes back). Disambiguating between the candidates at runtime requires a Binary Parameter
 * rule named after each candidate under the same registry PID — authoring that rule is the Visual
 * Rule Builder's job (not yet built), so every ruleset deploy returns a `warnings` entry flagging the
 * still-missing rule rather than fabricating one.
 */
/** The fixed registry PID under which JMS agreements are stored. */
export const JMS_AGREEMENTS_PID = "_Maintain_JMS_Agreements";
/** The fixed registry PID under which Common Router agreements are stored (mirrors {@link JMS_AGREEMENTS_PID}). */
export const ROUTER_AGREEMENTS_PID = "_Maintain_Router_Agreements";
//# sourceMappingURL=dto.js.map