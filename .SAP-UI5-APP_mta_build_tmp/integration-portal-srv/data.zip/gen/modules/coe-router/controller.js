import { coeRouterService } from "./service.js";
/** HTTP handlers for the CoE Route Wizard module. Thin: parse request, call the service, shape response. */
/** POST /check — resolves the normal-vs-ruleset agreement track for a parsed IDoc (body validated by the router). */
export async function checkAgreement(req, res) {
    res.json(await coeRouterService.checkAgreement(req.body));
}
/** POST /deploy — creates the route's Partner Directory parameters (body validated by the router). */
export async function deployRoute(req, res) {
    res.json(await coeRouterService.deployRoute(req.body));
}
/** POST /router/check — resolves the Common Router agreement track (body validated by the router). */
export async function checkRouterAgreement(req, res) {
    res.json(await coeRouterService.checkRouterAgreement(req.body));
}
/** POST /router/deploy — creates the Common Router parameters (body validated by the router). */
export async function deployCommonRouter(req, res) {
    res.json(await coeRouterService.deployCommonRouter(req.body));
}
/** POST /combined/check — resolves both the JMS and Common Router tracks (body validated by the router). */
export async function checkCombinedAgreement(req, res) {
    res.json(await coeRouterService.checkCombinedAgreement(req.body));
}
/** POST /combined/deploy — creates the combined JMS + Common Router parameters (body validated by the router). */
export async function deployJmsAndRouter(req, res) {
    res.json(await coeRouterService.deployJmsAndRouter(req.body));
}
/** GET /agreement/lookup — read-only sender/receiver pair lookup for the Parameter Registry (query validated by the router). */
export async function lookupAgreement(req, res) {
    res.json(await coeRouterService.lookupAgreement(req.query));
}
/** GET /present-in — reverse lookup of every agreement entry routing to a target PID (query validated by the router). */
export async function presentIn(req, res) {
    res.json(await coeRouterService.presentIn(req.query.targetPid));
}
//# sourceMappingURL=controller.js.map