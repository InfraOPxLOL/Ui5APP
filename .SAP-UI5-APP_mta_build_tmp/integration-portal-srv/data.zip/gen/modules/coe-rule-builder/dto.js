/**
 * DTOs for the CoE Visual Rule Builder — authors the rule content a `RULESET_.{SNDPRN}.{RCVPRN}`
 * entry references (spec — Visual Rule Builder / Binary Parameters, deferred from the original CoE
 * framework message until Binary Parameter support existed).
 *
 * Storage model (confirmed against the live tenant's `$metadata`): a rule is one Partner Directory
 * **binary** parameter (`BinaryParameters` entity set, key `(Pid, Id)`, `ContentType` +
 * `Edm.Binary Value` with no `m:HasStream` — travels as a plain base64 string like any other JSON
 * field). Per the confirmed ruleset mechanism (`coe-router` module): `RULESET_.{SNDPRN}.{RCVPRN}`
 * (a *string* parameter) holds a comma-separated list of rule names; each name is the Id of a binary
 * parameter under the **same** registry PID (`_Maintain_JMS_Agreements` / `_Maintain_Router_Agreements`)
 * holding that rule's JSON, base64-encoded. Encoding/decoding happens entirely in this module — the
 * frontend only ever sees/sends plain `Rule` JSON over `/api/v1/coe-rule-builder`.
 *
 * Two rule kinds:
 * - **Agreement Ruleset** — a flat identifying-query list that decides whether this rule's target
 *   applies to an incoming message (Rule Name, Identifying Queries, Target Routing).
 * - **X-Cast Endpoint Resolver** — a nested if/else-if/else condition chain that resolves the final
 *   routing output (JMS / ProcessDirect / Terminate), allowing arbitrary nesting per branch.
 */
export {};
//# sourceMappingURL=dto.js.map