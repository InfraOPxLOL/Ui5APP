import { createOperationsEngine } from "../../config/operationsEngineFactory.js";
import { HttpError } from "../../core/errors/HttpError.js";
/** Mock-engine settings used when the Operations Engine runs against the mock providers. */
const MOCK_CONFIG = { enabled: true, defaultScenario: "success" };
/**
 * The content type the Visual Rule Builder always writes. Confirmed live: CPI's `BinaryParameters`
 * rejects standard MIME types (`400 Bad Request`, "invalid content type application/json") — it only
 * accepts the short tags `xml`, `xsd`, `xsl`, `json`, `text`, `crt`, `gz`, `zip`, `zlib`, optionally
 * with `;encoding=…`.
 */
const RULE_CONTENT_TYPE = "json;encoding=UTF-8";
/**
 * Aggregation service for the CoE Visual Rule Builder. Rules are Partner Directory **binary**
 * parameters (spec/`dto.ts`): this layer owns the JSON⇄base64 boundary entirely — every other layer,
 * frontend included, only ever sees plain `Rule` JSON. No SDK/OData/CPI shape leaves this layer.
 */
export class CoeRuleBuilderService {
    engineFactory;
    constructor(engineFactory = () => createOperationsEngine(MOCK_CONFIG)) {
        this.engineFactory = engineFactory;
    }
    /**
     * Reads and decodes one rule.
     * @param pid the owning registry PID (e.g. `_Maintain_JMS_Agreements`).
     * @param id the rule name (matches a `RULESET_.{SNDPRN}.{RCVPRN}` candidate entry).
     * @returns the decoded rule.
     * @throws {HttpError} 404 when the rule does not exist.
     * @throws {SyntaxError} when the stored content is not valid JSON (surfaced, not swallowed — a
     *   corrupted/foreign binary parameter under this PID should fail loudly, not silently disappear).
     */
    async getRule(pid, id) {
        const engine = this.engineFactory();
        const parameter = await engine.partnerDirectory.getBinaryParameter(pid, id);
        if (parameter === undefined) {
            throw HttpError.notFound(`No rule "${id}" under ${pid}.`);
        }
        return CoeRuleBuilderService.decode(parameter);
    }
    /**
     * Lists every rule under a registry PID, decoding just enough to summarize (`kind`) without
     * failing the whole list when one entry isn't recognized JSON — that entry's `kind` is reported
     * `undefined` instead.
     * @param pid the owning registry PID.
     * @returns the rule summaries (empty when the PID has none).
     */
    async listRules(pid) {
        const engine = this.engineFactory();
        const parameters = await engine.partnerDirectory.listBinaryParameters(pid);
        return {
            pid,
            rules: parameters.map((parameter) => {
                let kind;
                try {
                    const decoded = CoeRuleBuilderService.decode(parameter);
                    kind = decoded.kind;
                }
                catch {
                    kind = undefined;
                }
                return {
                    pid: parameter.pid,
                    id: parameter.id,
                    kind,
                    lastModifiedBy: parameter.lastModifiedBy,
                    lastModifiedAt: parameter.lastModifiedAt,
                };
            }),
        };
    }
    /**
     * Encodes and persists one rule.
     * @param pid the owning registry PID.
     * @param id the rule name.
     * @param rule the rule content.
     * @returns the persisted rule as read back from the tenant.
     */
    async saveRule(pid, id, rule) {
        const engine = this.engineFactory();
        const valueBase64 = Buffer.from(JSON.stringify(rule), "utf-8").toString("base64");
        const saved = await engine.partnerDirectory.saveBinaryParameter(pid, id, RULE_CONTENT_TYPE, valueBase64);
        return CoeRuleBuilderService.decode(saved);
    }
    /**
     * Deletes one rule.
     * @param pid the owning registry PID.
     * @param id the rule name.
     */
    async deleteRule(pid, id) {
        const engine = this.engineFactory();
        await engine.partnerDirectory.deleteBinaryParameter(pid, id);
    }
    static decode(parameter) {
        const json = Buffer.from(parameter.valueBase64, "base64").toString("utf-8");
        return JSON.parse(json);
    }
}
/** Shared service instance. */
export const coeRuleBuilderService = new CoeRuleBuilderService();
//# sourceMappingURL=service.js.map