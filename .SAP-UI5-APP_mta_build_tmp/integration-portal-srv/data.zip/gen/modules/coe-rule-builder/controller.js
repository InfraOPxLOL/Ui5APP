import { coeRuleBuilderService } from "./service.js";
/** HTTP handlers for the CoE Visual Rule Builder. Thin: parse request, call the service, shape response. */
/** GET /?pid=…&id=… — reads and decodes one rule. 404 when it does not exist (thrown by the service). */
export async function getRule(req, res) {
    res.json(await coeRuleBuilderService.getRule(req.query.pid, req.query.id));
}
/** GET /list?pid=… — lists the rules under a registry PID. */
export async function listRules(req, res) {
    const pid = req.query.pid;
    res.json(await coeRuleBuilderService.listRules(pid));
}
/** PUT / — creates or updates one rule (body validated by the router). */
export async function saveRule(req, res) {
    const { pid, id, rule } = req.body;
    res.json(await coeRuleBuilderService.saveRule(pid, id, rule));
}
/** DELETE /?pid=…&id=… — deletes one rule. */
export async function deleteRule(req, res) {
    await coeRuleBuilderService.deleteRule(req.query.pid, req.query.id);
    res.status(204).end();
}
//# sourceMappingURL=controller.js.map