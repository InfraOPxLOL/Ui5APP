import { createOperationsEngine } from "../../config/operationsEngineFactory.js";
/** Mock-engine settings used when the Operations Engine runs against the mock providers. */
const MOCK_CONFIG = { enabled: true, defaultScenario: "success" };
/**
 * Aggregation service for the Global Partner Parameter Registry (spec §2, Tile 3). Lists, edits and
 * deletes Partner Directory string parameters under a Partner ID through `engine.partnerDirectory`.
 * No SDK/OData/CPI shape leaves this layer.
 */
export class CoeRegistryService {
    engineFactory;
    constructor(engineFactory = () => createOperationsEngine(MOCK_CONFIG)) {
        this.engineFactory = engineFactory;
    }
    /**
     * Lists every string parameter under a Partner ID.
     * @param pid the owning Partner ID.
     * @returns the parameters (empty when the PID has none).
     */
    async listByPid(pid) {
        const engine = this.engineFactory();
        const parameters = await engine.partnerDirectory.listStringParameters(pid);
        return { pid, parameters: parameters.map(CoeRegistryService.toDto) };
    }
    /**
     * Edits (or creates) one parameter's value.
     * @param update the parameter to persist.
     * @returns the persisted parameter as read back from the tenant.
     */
    async updateParameter(update) {
        const engine = this.engineFactory();
        const saved = await engine.partnerDirectory.saveStringParameter(update.pid, update.id, update.value);
        return CoeRegistryService.toDto(saved);
    }
    /**
     * Deletes one parameter.
     * @param pid the owning Partner ID.
     * @param id the parameter id.
     */
    async deleteParameter(pid, id) {
        const engine = this.engineFactory();
        await engine.partnerDirectory.deleteStringParameter(pid, id);
    }
    static toDto(parameter) {
        return {
            pid: parameter.pid,
            id: parameter.id,
            value: parameter.value,
            lastModifiedBy: parameter.lastModifiedBy,
            lastModifiedAt: parameter.lastModifiedAt,
        };
    }
}
/** Shared service instance. */
export const coeRegistryService = new CoeRegistryService();
//# sourceMappingURL=service.js.map