/**
 * DTOs for the Global Partner Parameter Registry (spec §2, Tile 3 — "View / Search / Edit Active
 * Rulesets"). A PID-scoped view/edit/delete surface over Partner Directory string parameters,
 * composed entirely from the Operations Engine's Partner Directory engine.
 */
export {};
//# sourceMappingURL=dto.js.map