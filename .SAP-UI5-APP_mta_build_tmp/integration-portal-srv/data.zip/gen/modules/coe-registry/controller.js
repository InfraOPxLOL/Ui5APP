import { coeRegistryService } from "./service.js";
/** HTTP handlers for the Global Partner Parameter Registry. Thin: parse request, call the service. */
/** GET /?pid=… — lists the parameters under a Partner ID. */
export async function getRegistry(req, res) {
    const pid = req.query.pid;
    res.json(await coeRegistryService.listByPid(pid));
}
/** PUT / — edits one parameter's value (body validated by the router). */
export async function updateParameter(req, res) {
    res.json(await coeRegistryService.updateParameter(req.body));
}
/** DELETE /?pid=…&id=… — deletes one parameter. */
export async function deleteParameter(req, res) {
    await coeRegistryService.deleteParameter(req.query.pid, req.query.id);
    res.status(204).end();
}
//# sourceMappingURL=controller.js.map