import { Router } from "express";
import { catchAsync } from "../../core/middleware/errorHandler.middleware.js";
import { validateRequest } from "../../core/middleware/validateRequest.middleware.js";
import { listQuerySchema } from "./validators.js";
import * as controller from "./controller.js";
/** Router for the Live Monitoring module, mounted at /api/v1/live-monitoring. */
export const liveMonitoringRouter = Router();
liveMonitoringRouter.get("/", validateRequest({ query: listQuerySchema }), catchAsync(controller.list));
//# sourceMappingURL=routes.js.map