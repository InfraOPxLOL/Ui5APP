import { liveMonitoringService } from "./service.js";
/**
 * HTTP handlers for the Live Monitoring module. Thin: parse request, call the service, shape response.
 */
/**
 * GET / — lists Live Monitoring rows.
 * @param req the request.
 * @param res the response.
 */
export async function list(req, res) {
    res.json(await liveMonitoringService.list(req.query));
}
//# sourceMappingURL=controller.js.map