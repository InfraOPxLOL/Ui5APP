import { createOperationsEngine } from "../../config/operationsEngineFactory.js";
import { JMS_AGREEMENTS_PID, ROUTER_AGREEMENTS_PID } from "../coe-router/dto.js";
import { fromStorageKey, parseRouteKey } from "../coe-router/service.js";
/** Mock-engine settings used when the Operations Engine runs against the mock providers. */
const MOCK_CONFIG = { enabled: true, defaultScenario: "success" };
const JMS_QUEUE_PREFIX = "QUEUE_JMS_";
const JMS_ENDPOINT_PREFIX = "ROUTE_JMS_";
const JMS_MAPPING_PREFIX = "RCV_JMS_";
const ROUTER_ROUTE_PREFIX = "ROUTE_";
/**
 * Aggregation service for the Global Partner Master-Detail Dashboard. Read-only: derives the master
 * list of known partners from the two agreement registries and, per partner, reverse-engineers its
 * raw string parameters into structured routes through `engine.partnerDirectory`. No SDK/OData/CPI
 * shape leaves this layer.
 */
export class CoePartnerDashboardService {
    engineFactory;
    constructor(engineFactory = () => createOperationsEngine(MOCK_CONFIG)) {
        this.engineFactory = engineFactory;
    }
    /**
     * Derives the master list: every distinct Partner ID referenced as a target (plain agreement value,
     * or one of a `RULESET_` entry's comma-separated candidates) by either agreement registry.
     * @returns the master list, sorted by Partner ID.
     */
    async listPartners() {
        const engine = this.engineFactory();
        const [jms, router] = await Promise.all([
            engine.partnerDirectory.listStringParameters(JMS_AGREEMENTS_PID),
            engine.partnerDirectory.listStringParameters(ROUTER_AGREEMENTS_PID),
        ]);
        const counts = new Map();
        const scan = (parameters, key) => {
            for (const parameter of parameters) {
                for (const candidate of CoePartnerDashboardService.splitCandidates(parameter.value)) {
                    const entry = counts.get(candidate) ?? { jms: 0, router: 0 };
                    entry[key] += 1;
                    counts.set(candidate, entry);
                }
            }
        };
        scan(jms, "jms");
        scan(router, "router");
        const partners = [...counts.entries()]
            .map(([pid, count]) => ({
            pid,
            jmsAgreementCount: count.jms,
            routerAgreementCount: count.router,
        }))
            .sort((a, b) => a.pid.localeCompare(b.pid));
        return { partners };
    }
    /**
     * Reverse-engineers one Partner ID's configuration: its route-keyed parameters decoded into
     * structured JMS/Router routes, everything else surfaced as flat "other" parameters, and every
     * agreement entry that routes here (with rule-authored status for ruleset candidates).
     * @param pid the Partner ID to inspect.
     * @returns the full detail view.
     */
    async getPartnerDetail(pid) {
        const engine = this.engineFactory();
        const [parameters, jmsAgreements, routerAgreements] = await Promise.all([
            engine.partnerDirectory.listStringParameters(pid),
            engine.partnerDirectory.listStringParameters(JMS_AGREEMENTS_PID),
            engine.partnerDirectory.listStringParameters(ROUTER_AGREEMENTS_PID),
        ]);
        const jmsByStorageKey = new Map();
        const routerByStorageKey = new Map();
        const other = [];
        for (const parameter of parameters) {
            if (parameter.id.startsWith(JMS_QUEUE_PREFIX)) {
                const key = parameter.id.slice(JMS_QUEUE_PREFIX.length);
                const acc = jmsByStorageKey.get(key) ?? {
                    queue: undefined,
                    endpointUri: undefined,
                    mappingAddress: undefined,
                };
                acc.queue = parameter.value;
                jmsByStorageKey.set(key, acc);
            }
            else if (parameter.id.startsWith(JMS_ENDPOINT_PREFIX)) {
                const key = parameter.id.slice(JMS_ENDPOINT_PREFIX.length);
                const acc = jmsByStorageKey.get(key) ?? {
                    queue: undefined,
                    endpointUri: undefined,
                    mappingAddress: undefined,
                };
                acc.endpointUri = parameter.value;
                jmsByStorageKey.set(key, acc);
            }
            else if (parameter.id.startsWith(JMS_MAPPING_PREFIX)) {
                const key = parameter.id.slice(JMS_MAPPING_PREFIX.length);
                const acc = jmsByStorageKey.get(key) ?? {
                    queue: undefined,
                    endpointUri: undefined,
                    mappingAddress: undefined,
                };
                acc.mappingAddress = parameter.value;
                jmsByStorageKey.set(key, acc);
            }
            else if (parameter.id.startsWith(ROUTER_ROUTE_PREFIX)) {
                const key = parameter.id.slice(ROUTER_ROUTE_PREFIX.length);
                routerByStorageKey.set(key, parameter.value);
            }
            else {
                other.push({
                    id: parameter.id,
                    value: parameter.value,
                    lastModifiedBy: parameter.lastModifiedBy,
                    lastModifiedAt: parameter.lastModifiedAt,
                });
            }
        }
        const jmsRoutes = [...jmsByStorageKey.entries()]
            .map(([storageKey, acc]) => CoePartnerDashboardService.decodeJmsRoute(storageKey, acc))
            .filter((route) => route !== undefined)
            .sort((a, b) => a.routeKey.localeCompare(b.routeKey));
        const routerRoutes = [...routerByStorageKey.entries()]
            .map(([storageKey, finalTargetPid]) => CoePartnerDashboardService.decodeRouterRoute(storageKey, finalTargetPid))
            .filter((route) => route !== undefined)
            .sort((a, b) => a.routeKey.localeCompare(b.routeKey));
        const [jmsRefs, routerRefs] = await Promise.all([
            CoePartnerDashboardService.referencedByFrom(engine, jmsAgreements, JMS_AGREEMENTS_PID, pid),
            CoePartnerDashboardService.referencedByFrom(engine, routerAgreements, ROUTER_AGREEMENTS_PID, pid),
        ]);
        return {
            pid,
            jmsRoutes,
            routerRoutes,
            otherParameters: other.sort((a, b) => a.id.localeCompare(b.id)),
            referencedBy: [...jmsRefs, ...routerRefs],
        };
    }
    static decodeJmsRoute(storageKey, acc) {
        const routeKey = fromStorageKey(storageKey);
        const parts = parseRouteKey(routeKey);
        if (parts === undefined) {
            return undefined;
        }
        return { routeKey, ...parts, ...acc };
    }
    static decodeRouterRoute(storageKey, finalTargetPid) {
        const routeKey = fromStorageKey(storageKey);
        const parts = parseRouteKey(routeKey);
        if (parts === undefined) {
            return undefined;
        }
        return { routeKey, ...parts, finalTargetPid };
    }
    static async referencedByFrom(engine, parameters, storePid, pid) {
        const matches = parameters.filter((parameter) => CoePartnerDashboardService.splitCandidates(parameter.value).includes(pid));
        return Promise.all(matches.map(async (parameter) => {
            const isRuleset = parameter.id.startsWith("RULESET_");
            const ruleAuthored = isRuleset
                ? (await engine.partnerDirectory.getBinaryParameter(storePid, pid)) !== undefined
                : undefined;
            return { storePid, id: parameter.id, value: parameter.value, isRuleset, ruleAuthored };
        }));
    }
    static splitCandidates(value) {
        return value
            .split(",")
            .map((candidate) => candidate.trim())
            .filter((candidate) => candidate !== "");
    }
}
/** Shared service instance. */
export const coePartnerDashboardService = new CoePartnerDashboardService();
//# sourceMappingURL=service.js.map