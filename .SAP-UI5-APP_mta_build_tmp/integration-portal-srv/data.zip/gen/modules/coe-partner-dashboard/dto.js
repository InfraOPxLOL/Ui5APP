/**
 * DTOs for the Global Partner Master-Detail Dashboard (Parameter Registry's companion view). Composed
 * entirely from the Operations Engine's Partner Directory engine, reusing `coe-router`'s route-key
 * conventions (`buildRouteKey`/`toStorageKey`/`parseRouteKey`/`fromStorageKey`) to reverse-engineer a
 * Partner ID's raw string parameters back into structured routes, so a developer can browse what a
 * partner already has configured without hand-decoding parameter Ids.
 *
 * There is no tenant capability to enumerate every Partner ID, so the **master list is derived**:
 * every distinct value (or `RULESET_` candidate) referenced by either agreement registry
 * (`_Maintain_JMS_Agreements` / `_Maintain_Router_Agreements`) is a "known partner". A Partner ID with
 * parameters but never referenced by an agreement will not appear — General Search's "By Partner ID"
 * mode remains the fallback for looking up an arbitrary PID directly.
 */
export {};
//# sourceMappingURL=dto.js.map