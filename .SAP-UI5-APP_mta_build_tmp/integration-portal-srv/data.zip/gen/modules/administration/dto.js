/**
 * Data transfer objects for the Administration module. These are the platform's stable shapes; the
 * service maps raw configuration/CPI payloads into them so no internal shape leaks past the
 * service layer.
 */
export {};
//# sourceMappingURL=dto.js.map