import { valueMappingService } from "./service.js";
/**
 * HTTP handlers for the Value Mapping module. Thin: parse request, call the service, shape response.
 */
/**
 * GET / — lists Value Mapping rows.
 * @param req the request.
 * @param res the response.
 */
export async function list(req, res) {
    res.json(await valueMappingService.list(req.query));
}
//# sourceMappingURL=controller.js.map