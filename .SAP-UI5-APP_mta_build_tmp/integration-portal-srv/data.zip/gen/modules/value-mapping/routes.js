import { Router } from "express";
import { catchAsync } from "../../core/middleware/errorHandler.middleware.js";
import { validateRequest } from "../../core/middleware/validateRequest.middleware.js";
import { listQuerySchema } from "./validators.js";
import * as controller from "./controller.js";
/** Router for the Value Mapping module, mounted at /api/v1/value-mapping. */
export const valueMappingRouter = Router();
valueMappingRouter.get("/", validateRequest({ query: listQuerySchema }), catchAsync(controller.list));
//# sourceMappingURL=routes.js.map