import { createOperationsEngine } from "../../config/operationsEngineFactory.js";
/** Mock-engine settings used when the Operations Engine runs against the mock providers. */
const MOCK_CONFIG = { enabled: true, defaultScenario: "success" };
/**
 * Aggregation service for the Runtime Center (Phase 12). Builds a fresh, request-scoped
 * {@link OperationsEngine} per call (matching every other Operations-Engine-consuming module) and
 * delegates entirely to `engine.runtimeCenter` — this service adds no business logic of its own,
 * only the HTTP-facing seam (deriving `actor` from the caller's identity for redeploys).
 *
 * Deployment Timeline and failure-trend samples live in `RuntimeCenterStateStore`'s process-lifetime
 * singleton (see its own doc comment), so they survive across the many short-lived engines this
 * service constructs.
 */
export class RuntimeCenterService {
    engineFactory;
    constructor(engineFactory = () => createOperationsEngine(MOCK_CONFIG)) {
        this.engineFactory = engineFactory;
    }
    async listCatalog() {
        return this.engineFactory().runtimeCenter.listCatalog();
    }
    async getDetails(artifactId) {
        return this.engineFactory().runtimeCenter.getDetails(artifactId);
    }
    async getHealth(artifactId) {
        return this.engineFactory().runtimeCenter.getHealth(artifactId);
    }
    async getDeploymentTimeline(artifactId) {
        return this.engineFactory().runtimeCenter.getDeploymentTimeline(artifactId);
    }
    async redeploy(artifactId, actor) {
        return this.engineFactory().runtimeCenter.redeploy(artifactId, actor);
    }
}
/** Shared service instance. */
export const runtimeCenterService = new RuntimeCenterService();
//# sourceMappingURL=service.js.map