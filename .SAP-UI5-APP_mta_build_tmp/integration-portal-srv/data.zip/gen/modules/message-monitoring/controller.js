import { messageMonitoringService } from "./service.js";
import { HttpError } from "../../core/errors/HttpError.js";
/**
 * HTTP handlers for the Message Investigation Workspace (Phase 9). Thin: parse the request, call the
 * service, shape the response.
 */
function toListQuery(query) {
    const q = query;
    return {
        status: q.status,
        severity: q.severity,
        sender: q.sender,
        receiver: q.receiver,
        messageType: q.messageType,
        customStatus: q.customStatus,
        applicationId: q.applicationId,
        integrationFlow: q.integrationFlow,
        correlationId: q.correlationId,
        queue: q.queue,
        search: q.search,
        dateFrom: q.dateFrom,
        dateTo: q.dateTo,
        durationMinMs: q.durationMinMs === undefined ? undefined : Number(q.durationMinMs),
        durationMaxMs: q.durationMaxMs === undefined ? undefined : Number(q.durationMaxMs),
        smartFilter: q.smartFilter,
        framework: q.framework,
        recoveryState: q.recoveryState,
        page: q.page === undefined ? undefined : Number(q.page),
        pageSize: q.pageSize === undefined ? undefined : Number(q.pageSize),
        sortBy: q.sortBy,
        sortDirection: q.sortDirection,
    };
}
/** GET / — lists investigation rows. */
export async function list(req, res) {
    res.json(await messageMonitoringService.list(toListQuery(req.query)));
}
/** GET /:messageId — full investigation detail. */
export async function getById(req, res) {
    const detail = await messageMonitoringService.getById(req.params.messageId);
    if (detail === undefined) {
        throw HttpError.notFound(`No message found with id "${String(req.params.messageId)}".`);
    }
    res.json(detail);
}
/** GET /:messageId/related — related-message groups. */
export async function getRelated(req, res) {
    res.json(await messageMonitoringService.getRelated(req.params.messageId));
}
/** GET /:messageId/context — investigation panel context. */
export async function getContext(req, res) {
    const context = await messageMonitoringService.getContext(req.params.messageId);
    if (context === undefined) {
        throw HttpError.notFound(`No message found with id "${String(req.params.messageId)}".`);
    }
    res.json(context);
}
/** GET /export — bulk export of the current filtered working set. */
export async function exportRows(req, res) {
    const query = toListQuery(req.query);
    const format = req.query.format;
    const model = await messageMonitoringService.exportRows(query, format);
    res.setHeader("Content-Type", model.mimeType);
    res.setHeader("Content-Disposition", `attachment; filename="${model.fileName}"`);
    res.send(model.content);
}
/** GET /:messageId/jms-eligibility — cheap JMS-retryable classification. */
export async function getJmsEligibility(req, res) {
    res.json(await messageMonitoringService.checkJmsEligibility(req.params.messageId));
}
/** GET /:messageId/retry-check — full JMS retry resolution (queue + retry count, or manual-selection). */
export async function getRetryCheck(req, res) {
    res.json(await messageMonitoringService.getRetryCheck(req.params.messageId));
}
/** POST /:messageId/retry — executes a real JMS retry. */
export async function retry(req, res) {
    const body = req.body;
    res.json(await messageMonitoringService.retry(req.params.messageId, body.queueName, body.reason));
}
// --- Framework awareness & recovery (Phase 13) ---------------------------------
/** GET /:messageId/framework — full framework detection, with the evidence behind it. */
export async function getFramework(req, res) {
    res.json(await messageMonitoringService.getFramework(req.params.messageId));
}
/** GET /:messageId/recovery-plan — resolves one message's recovery plan (read-only). */
export async function getRecoveryPlan(req, res) {
    const queueName = req.query.queueName;
    res.json(await messageMonitoringService.getRecoveryPlan(req.params.messageId, queueName));
}
/** POST /recovery-plan — builds the pre-execution plan for a selection of messages (§9). */
export async function buildRecoveryPlan(req, res) {
    const body = req.body;
    res.json(await messageMonitoringService.buildRecoveryPlan(body.messageIds));
}
/** POST /:messageId/recover — executes framework-aware recovery (move → verify → retry). */
export async function recover(req, res) {
    const body = req.body;
    res.json(await messageMonitoringService.recover(req.params.messageId, body.reason, body.queueName));
}
//# sourceMappingURL=controller.js.map