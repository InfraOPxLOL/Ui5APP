import { createOperationsEngine } from "../../config/operationsEngineFactory.js";
/** Mock-engine settings used when the Operations Engine runs against the mock providers. */
const MOCK_CONFIG = { enabled: true, defaultScenario: "success" };
/** The master CoE Partner ID whose parameters hold the global framework settings (spec §3). */
const SYS_PID = ".SYS_JMS_FRAMEWORK";
/** The four parameter ids under {@link SYS_PID} that back the global settings form (spec §3). */
const PARAM_IDS = {
    environment: "Environment",
    defaultRetries: "DEFAULT_RETRIES",
    defaultExceptionTo: "Default_Exception_To",
    defaultEgressUri: "X-Default-Egress-URI",
};
/**
 * Aggregation service for the CoE Admin module (spec §3 — Global Framework Configurations). Builds a
 * fresh, request-scoped {@link OperationsEngine} per call (matching every other Operations-Engine-
 * consuming module) and reads/writes the four `.SYS_JMS_FRAMEWORK` string parameters through
 * `engine.partnerDirectory`. No SDK, OData or CPI shape ever leaves this layer.
 */
export class CoeAdminService {
    engineFactory;
    constructor(engineFactory = () => createOperationsEngine(MOCK_CONFIG)) {
        this.engineFactory = engineFactory;
    }
    /**
     * Reads the current global settings from the Partner Directory.
     * @returns the four settings; any field is `undefined` when not yet set on the tenant.
     */
    async getGlobalSettings() {
        const engine = this.engineFactory();
        const [environment, defaultRetries, defaultExceptionTo, defaultEgressUri] = await Promise.all([
            engine.partnerDirectory.getStringParameter(SYS_PID, PARAM_IDS.environment),
            engine.partnerDirectory.getStringParameter(SYS_PID, PARAM_IDS.defaultRetries),
            engine.partnerDirectory.getStringParameter(SYS_PID, PARAM_IDS.defaultExceptionTo),
            engine.partnerDirectory.getStringParameter(SYS_PID, PARAM_IDS.defaultEgressUri),
        ]);
        return CoeAdminService.toDto([
            environment,
            defaultRetries,
            defaultExceptionTo,
            defaultEgressUri,
        ]);
    }
    /**
     * Persists the global settings, writing each field as a `.SYS_JMS_FRAMEWORK` string parameter.
     * @param update the validated settings.
     * @returns the settings as read back from the tenant after the write.
     */
    async saveGlobalSettings(update) {
        const engine = this.engineFactory();
        await Promise.all([
            engine.partnerDirectory.saveStringParameter(SYS_PID, PARAM_IDS.environment, update.environment),
            engine.partnerDirectory.saveStringParameter(SYS_PID, PARAM_IDS.defaultRetries, String(update.defaultRetries)),
            engine.partnerDirectory.saveStringParameter(SYS_PID, PARAM_IDS.defaultExceptionTo, update.defaultExceptionTo),
            engine.partnerDirectory.saveStringParameter(SYS_PID, PARAM_IDS.defaultEgressUri, update.defaultEgressUri),
        ]);
        return this.getGlobalSettings();
    }
    static toDto(parameters) {
        const [environment, defaultRetries, defaultExceptionTo, defaultEgressUri] = parameters;
        const retries = defaultRetries?.value === undefined ? undefined : Number(defaultRetries.value);
        return {
            environment: environment?.value,
            defaultRetries: retries === undefined || Number.isNaN(retries) ? undefined : retries,
            defaultExceptionTo: defaultExceptionTo?.value,
            defaultEgressUri: defaultEgressUri?.value,
            lastModifiedBy: CoeAdminService.mostRecentModifier(parameters),
            lastModifiedAt: CoeAdminService.mostRecentTimestamp(parameters),
        };
    }
    static mostRecentTimestamp(parameters) {
        const timestamps = parameters
            .map((parameter) => parameter?.lastModifiedAt)
            .filter((value) => value !== undefined)
            .sort();
        return timestamps.at(-1);
    }
    static mostRecentModifier(parameters) {
        const latest = parameters
            .filter((parameter) => parameter?.lastModifiedAt !== undefined)
            .sort((a, b) => (a.lastModifiedAt ?? "").localeCompare(b.lastModifiedAt ?? ""))
            .at(-1);
        return latest?.lastModifiedBy;
    }
}
/** Shared service instance. */
export const coeAdminService = new CoeAdminService();
//# sourceMappingURL=service.js.map