import { coeAdminService } from "./service.js";
/** HTTP handlers for the CoE Admin module. Thin: parse request, call the service, shape response. */
/** GET / — the current global framework settings. */
export async function getGlobalSettings(_req, res) {
    res.json(await coeAdminService.getGlobalSettings());
}
/** PUT / — persists the global framework settings (body already validated by the router). */
export async function saveGlobalSettings(req, res) {
    const update = req.body;
    res.json(await coeAdminService.saveGlobalSettings(update));
}
//# sourceMappingURL=controller.js.map