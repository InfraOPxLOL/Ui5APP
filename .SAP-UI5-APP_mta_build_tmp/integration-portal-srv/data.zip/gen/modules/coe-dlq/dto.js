/**
 * DTOs for the DLQ & Intelligent Recovery Dashboard (spec §6, Tile 4). The master list is failed
 * messages read from the MPL monitoring API; the detail/recovery view resolves the target JMS queue
 * for a message via the Partner Directory (the read side of spec §6C's "intelligent retry queue
 * resolution algorithm"). Composed entirely from the Operations Engine.
 */
export {};
//# sourceMappingURL=dto.js.map