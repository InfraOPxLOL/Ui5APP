import { coeDlqService } from "./service.js";
/** HTTP handlers for the DLQ & Intelligent Recovery Dashboard. Thin: parse request, call the service. */
/** GET / — the failed-message master list. */
export async function listFailedMessages(_req, res) {
    res.json(await coeDlqService.listFailedMessages());
}
/** GET /:messageId/recovery — the recovery context (queue resolution + error details) for a message. */
export async function getRecovery(req, res) {
    res.json(await coeDlqService.getRecovery(req.params.messageId));
}
/** POST /:messageId/replay — attempts a replay (resolves the target queue). */
export async function replay(req, res) {
    res.json(await coeDlqService.replay(req.params.messageId));
}
//# sourceMappingURL=controller.js.map