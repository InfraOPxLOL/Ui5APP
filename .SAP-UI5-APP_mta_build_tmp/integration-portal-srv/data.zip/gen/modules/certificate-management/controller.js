import { certificateManagementService } from "./service.js";
/**
 * HTTP handlers for the Certificates module. Thin: parse request, call the service, shape response.
 */
/**
 * GET / — lists Certificates rows.
 * @param req the request.
 * @param res the response.
 */
export async function list(req, res) {
    res.json(await certificateManagementService.list(req.query));
}
//# sourceMappingURL=controller.js.map