import { Router } from "express";
import { catchAsync } from "../../core/middleware/errorHandler.middleware.js";
import { validateRequest } from "../../core/middleware/validateRequest.middleware.js";
import { listQuerySchema } from "./validators.js";
import * as controller from "./controller.js";
/** Router for the Certificates module, mounted at /api/v1/certificate-management. */
export const certificateManagementRouter = Router();
certificateManagementRouter.get("/", validateRequest({ query: listQuerySchema }), catchAsync(controller.list));
//# sourceMappingURL=routes.js.map