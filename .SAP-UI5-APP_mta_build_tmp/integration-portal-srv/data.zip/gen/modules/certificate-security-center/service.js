import { createOperationsEngine } from "../../config/operationsEngineFactory.js";
/** Mock-engine settings used when the Operations Engine runs against the mock providers. */
const MOCK_CONFIG = { enabled: true, defaultScenario: "success" };
/**
 * Aggregation service for the Certificate & Security Center (Phase 13). Builds a fresh,
 * request-scoped {@link OperationsEngine} per call (matching every other Operations-Engine-consuming
 * module) and delegates entirely to `engine.certificateSecurity` — this service adds no business
 * logic of its own, only the HTTP-facing seam (deriving `actor` from the caller's identity for the
 * flag-for-renewal action).
 *
 * The Timeline lives in `CertificateSecurityStateStore`'s process-lifetime singleton (see its own
 * doc comment), so it survives across the many short-lived engines this service constructs.
 */
export class CertificateSecurityCenterService {
    engineFactory;
    constructor(engineFactory = () => createOperationsEngine(MOCK_CONFIG)) {
        this.engineFactory = engineFactory;
    }
    async getDashboard() {
        return this.engineFactory().certificateSecurity.getDashboard();
    }
    async listCertificates() {
        return this.engineFactory().certificateSecurity.listCertificates();
    }
    async getCertificate(alias) {
        return this.engineFactory().certificateSecurity.getCertificate(alias);
    }
    async listSecurityMaterials() {
        return this.engineFactory().certificateSecurity.listSecurityMaterials();
    }
    async getTimeline(alias) {
        return this.engineFactory().certificateSecurity.getTimeline(alias);
    }
    async flagForRenewal(alias, actor) {
        return this.engineFactory().certificateSecurity.flagForRenewal(alias, actor);
    }
}
/** Shared service instance. */
export const certificateSecurityCenterService = new CertificateSecurityCenterService();
//# sourceMappingURL=service.js.map