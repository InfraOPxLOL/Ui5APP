import { z } from "zod";
import { HttpError } from "../errors/HttpError.js";
/**
 * Produces a middleware that validates request `params`, `query` and/or `body` against zod schemas
 * at the API boundary (architecture §14). Invalid input is rejected with a 422 before any service
 * runs; validated, typed values replace the raw request parts.
 * @param schemas the schemas to apply per request part.
 * @returns an Express validation middleware.
 */
export function validateRequest(schemas) {
    return (req, _res, next) => {
        try {
            if (schemas.params !== undefined) {
                req.params = schemas.params.parse(req.params);
            }
            if (schemas.query !== undefined) {
                Object.assign(req.query, schemas.query.parse(req.query));
            }
            if (schemas.body !== undefined) {
                req.body = schemas.body.parse(req.body);
            }
            next();
        }
        catch (error) {
            if (error instanceof z.ZodError) {
                next(HttpError.validation("Request validation failed.", error.issues));
                return;
            }
            next(error);
        }
    };
}
//# sourceMappingURL=validateRequest.middleware.js.map