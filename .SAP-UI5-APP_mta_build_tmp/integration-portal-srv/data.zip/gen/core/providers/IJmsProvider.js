export {};
//# sourceMappingURL=IJmsProvider.js.map