export {};
//# sourceMappingURL=IPayloadProvider.js.map