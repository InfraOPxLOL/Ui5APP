export {};
//# sourceMappingURL=IMonitoringProvider.js.map