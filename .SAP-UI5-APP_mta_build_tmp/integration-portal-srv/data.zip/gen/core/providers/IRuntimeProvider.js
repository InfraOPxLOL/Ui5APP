export {};
//# sourceMappingURL=IRuntimeProvider.js.map