export {};
//# sourceMappingURL=ICertificateProvider.js.map