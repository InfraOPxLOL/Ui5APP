export {};
//# sourceMappingURL=IIntegrationSuiteClient.js.map