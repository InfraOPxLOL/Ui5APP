export {};
//# sourceMappingURL=IPartnerDirectoryProvider.js.map