export {};
//# sourceMappingURL=ISplunkProvider.js.map