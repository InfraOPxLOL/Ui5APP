export {};
//# sourceMappingURL=IAlertProvider.js.map