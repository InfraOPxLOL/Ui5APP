/**
 * Domain types spoken by the provider interfaces (`core/providers/*`).
 *
 * These are the platform's neutral shapes for Integration Suite concepts — deliberately defined
 * here, not in any module, so provider implementations translate raw CPI payloads into them at the
 * boundary and no upstream schema ever leaks into module services. All types are plain data
 * (no behaviour) and readonly.
 */
export {};
//# sourceMappingURL=types.js.map