import { RestClient } from "./RestClient.js";
import { resolveDestination } from "../../config/destinations.js";
/**
 * The single authenticated gateway to SAP Integration Suite.
 *
 * Backend module services call CPI **only** through this client. It resolves the tenant's
 * destination (base URL + auth headers) via the Destination service, propagates the correlation id
 * so a request can be traced across both systems' logs (architecture §10), and delegates transport
 * and error normalization to {@link RestClient}. Because every CPI call funnels here, destination
 * resolution and auth are wired in exactly one place.
 */
export class IntegrationSuiteClient {
    rest;
    constructor(rest = new RestClient()) {
        this.rest = rest;
    }
    /**
     * Performs a GET against a CPI resource path.
     * @param path resource path relative to the tenant base URL (leading slash optional).
     * @param options request options.
     * @returns the parsed response typed as `T`.
     */
    async get(path, options = {}) {
        return this.send("GET", path, options);
    }
    /**
     * Performs a POST against a CPI resource path.
     * @param path resource path relative to the tenant base URL.
     * @param options request options (including body).
     * @returns the parsed response typed as `T`.
     */
    async post(path, options = {}) {
        return this.send("POST", path, options);
    }
    async send(method, path, options) {
        const destination = await resolveDestination(options.tenantId);
        const url = `${destination.url.replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
        const headers = { ...destination.headers };
        if (options.correlationId !== undefined) {
            headers["X-Correlation-Id"] = options.correlationId;
        }
        return this.rest.request(url, {
            method,
            headers,
            query: options.query,
            body: options.body,
        });
    }
}
/** Shared client instance for backend module services. */
export const integrationSuiteClient = new IntegrationSuiteClient();
//# sourceMappingURL=IntegrationSuiteClient.js.map