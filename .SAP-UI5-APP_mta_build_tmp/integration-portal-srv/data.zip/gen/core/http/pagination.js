import { z } from "zod";
/**
 * Builds an empty page. Used by Phase 1 placeholder service implementations so every list endpoint
 * returns a valid, typed envelope before its upstream CPI call is implemented.
 * @param top the page size echoed back (defaults to 50).
 * @returns an empty paged result.
 */
export function emptyPage(top = 50) {
    return { items: [], total: 0, skip: 0, top };
}
/**
 * Shared validation schema for list query parameters (paging, sorting, filtering). Coerces the
 * numeric paging params and applies safe bounds.
 */
export const paginationQuerySchema = z.object({
    $skip: z.coerce.number().int().min(0).optional(),
    $top: z.coerce.number().int().min(1).max(500).optional(),
    $orderby: z.string().optional(),
    $filter: z.string().optional(),
});
//# sourceMappingURL=pagination.js.map