import { AppError } from "./AppError.js";
/**
 * Client-facing 4xx errors with a stable code taxonomy. Factory methods cover the common cases so
 * controllers/services throw semantically (`HttpError.notFound(...)`) rather than assembling status
 * codes by hand.
 */
export class HttpError extends AppError {
    statusCode;
    code;
    constructor(statusCode, code, message, details) {
        super(message, details);
        this.statusCode = statusCode;
        this.code = code;
    }
    /** 400 Bad Request. */
    static badRequest(message, details) {
        return new HttpError(400, "BAD_REQUEST", message, details);
    }
    /** 401 Unauthorized. */
    static unauthorized(message = "Authentication required.") {
        return new HttpError(401, "UNAUTHORIZED", message);
    }
    /** 403 Forbidden. */
    static forbidden(message = "Insufficient permissions.") {
        return new HttpError(403, "FORBIDDEN", message);
    }
    /** 404 Not Found. */
    static notFound(message = "Resource not found.") {
        return new HttpError(404, "NOT_FOUND", message);
    }
    /** 409 Conflict. */
    static conflict(message, details) {
        return new HttpError(409, "CONFLICT", message, details);
    }
    /** 422 Unprocessable Entity (validation failure). */
    static validation(message, details) {
        return new HttpError(422, "VALIDATION_FAILED", message, details);
    }
}
//# sourceMappingURL=HttpError.js.map