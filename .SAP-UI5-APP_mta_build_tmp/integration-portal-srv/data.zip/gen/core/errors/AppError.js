/**
 * Base class for all backend errors.
 *
 * Every error carries a stable machine-readable {@link AppError.code} and an HTTP
 * {@link AppError.statusCode}; the terminal error middleware serializes these into the normalized
 * response envelope `{ code, message, correlationId, details? }`. Upstream (CPI) errors are mapped
 * into this taxonomy via {@link UpstreamError} so no raw CPI error shape ever reaches the client.
 */
export class AppError extends Error {
    /** Whether this error is safe/expected (operational) vs. a programming fault. */
    isOperational = true;
    /** Optional structured detail for diagnostics (never leaks secrets). */
    details;
    constructor(message, details, cause) {
        super(message, { cause });
        this.name = new.target.name;
        this.details = details;
    }
}
//# sourceMappingURL=AppError.js.map