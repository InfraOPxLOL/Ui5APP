import { AppError } from "./AppError.js";
/**
 * Named authentication/authorization errors. `HttpError.unauthorized()` / `HttpError.forbidden()`
 * remain valid shortcuts; these named classes exist so services can throw (and tests can assert
 * on) semantically-typed errors rather than status-coded generics, per the Phase-3 error-framework
 * mandate.
 */
/** The caller is not authenticated (no or invalid credentials) — HTTP 401. */
export class AuthenticationError extends AppError {
    statusCode = 401;
    code = "AUTHENTICATION_REQUIRED";
    constructor(message = "Authentication required.", details) {
        super(message, details);
    }
}
/** The caller is authenticated but lacks the required scope/permission — HTTP 403. */
export class AuthorizationError extends AppError {
    statusCode = 403;
    code = "INSUFFICIENT_PERMISSIONS";
    /** The missing scope, when known — surfaced in the error envelope's details. */
    missingScope;
    constructor(message = "Insufficient permissions.", missingScope) {
        super(message, missingScope !== undefined ? { missingScope } : undefined);
        this.missingScope = missingScope;
    }
}
//# sourceMappingURL=AuthErrors.js.map