import { logger } from "../logging/logger.js";
/**
 * Minimal in-process periodic job scheduler.
 *
 * Registers interval-based jobs (e.g. the certificate-expiry sweep that polls CPI and pushes over
 * WebSocket). Timers live in process memory only; there is no persisted schedule or run history,
 * consistent with the stateless-backend constraint. On multi-instance deployments each instance
 * runs its own timers — acceptable for idempotent polling, and a note for any future job that must
 * run singleton.
 */
export class Scheduler {
    timers = new Map();
    /**
     * Registers and starts a job.
     * @param job the job definition.
     */
    register(job) {
        if (this.timers.has(job.name)) {
            return;
        }
        const timer = setInterval(() => {
            job.run().catch((error) => {
                logger.error({ err: error, job: job.name }, "scheduled.jobFailed");
            });
        }, job.intervalMs);
        // Do not keep the event loop alive solely for jobs.
        timer.unref();
        this.timers.set(job.name, timer);
        logger.info({ job: job.name, intervalMs: job.intervalMs }, "scheduled.jobRegistered");
    }
    /**
     * Stops all registered jobs.
     */
    stopAll() {
        for (const timer of this.timers.values()) {
            clearInterval(timer);
        }
        this.timers.clear();
    }
}
/** Process-wide scheduler instance. */
export const scheduler = new Scheduler();
//# sourceMappingURL=scheduler.js.map