/** A field-operator-value comparison (e.g. `status eq 'FAILED'`). */
export class ODataComparisonExpression {
    field;
    operator;
    value;
    constructor(field, operator, value) {
        this.field = field;
        this.operator = operator;
        this.value = value;
    }
    render(version) {
        return `${this.field} ${this.operator} ${renderODataLiteral(this.value, version)}`;
    }
}
/** A string-function call (e.g. `contains(integrationFlow,'Order')`). */
export class ODataFunctionExpression {
    fn;
    field;
    value;
    constructor(fn, field, value) {
        this.fn = fn;
        this.field = field;
        this.value = value;
    }
    render(version) {
        return `${this.fn}(${this.field},${renderODataLiteral(this.value, version)})`;
    }
}
/** A logical AND/OR combination of sub-expressions, each parenthesized to preserve precedence. */
export class ODataCompositeExpression {
    operator;
    parts;
    constructor(operator, parts) {
        this.operator = operator;
        this.parts = parts;
    }
    render(version) {
        return this.parts.map((part) => `(${part.render(version)})`).join(` ${this.operator} `);
    }
}
/** A logical negation of a sub-expression. */
export class ODataNotExpression {
    inner;
    constructor(inner) {
        this.inner = inner;
    }
    render(version) {
        return `not (${this.inner.render(version)})`;
    }
}
/**
 * Renders a literal value per OData version rules: strings are single-quoted with embedded quotes
 * doubled; numbers/booleans are unquoted; dates use the `datetime'...'` literal in v2 and a bare
 * ISO 8601 string in v4 (per the respective Edm.DateTime / Edm.DateTimeOffset literal syntax).
 *
 * OData v2's `Edm.DateTime` literal grammar (`datetime'yyyy-mm-ddThh:mm:ss[.fffffff]'`) has **no**
 * timezone designator — unlike `Edm.DateTimeOffset`, which `datetimeoffset'...'` would carry one
 * for. `Date.prototype.toISOString()` always appends a trailing `Z`, which is not valid inside a v2
 * `datetime'...'` literal; SAP Integration Suite's OData v1 Monitoring API (and CPI's OData v2 stack
 * generally) rejects such a filter with an HTTP 400 rather than a parse error inside the payload, so
 * the trailing `Z` is stripped for v2 specifically. The underlying instant is unchanged (Edm.DateTime
 * has no offset to begin with — CPI's `LogStart` etc. are always UTC wall-clock values).
 * @param value the literal value.
 * @param version the target OData version.
 * @returns the rendered literal.
 */
export function renderODataLiteral(value, version) {
    if (typeof value === "number" || typeof value === "boolean") {
        return String(value);
    }
    if (value instanceof Date) {
        const iso = value.toISOString();
        return version === "v2" ? `datetime'${iso.replace(/Z$/, "")}'` : iso;
    }
    return `'${value.replace(/'/g, "''")}'`;
}
//# sourceMappingURL=ODataFilterExpression.js.map