import { ODataComparisonExpression, ODataCompositeExpression, ODataFunctionExpression, ODataNotExpression, } from "./ODataFilterExpression.js";
/**
 * Fluent factory for {@link ODataFilterExpression} trees — the only sanctioned way to build an
 * OData `$filter` value. Composing expressions this way (rather than concatenating strings)
 * guarantees correct literal quoting/escaping and precedence parenthesization for every filter the
 * SDK ever sends.
 *
 * @example
 * ODataFilter.and(
 *   ODataFilter.eq("status", "FAILED"),
 *   ODataFilter.contains("integrationFlow", "Order"),
 * )
 */
export class ODataFilter {
    /** `field eq value` */
    static eq(field, value) {
        return new ODataComparisonExpression(field, "eq", value);
    }
    /** `field ne value` */
    static ne(field, value) {
        return new ODataComparisonExpression(field, "ne", value);
    }
    /** `field gt value` */
    static gt(field, value) {
        return new ODataComparisonExpression(field, "gt", value);
    }
    /** `field ge value` */
    static ge(field, value) {
        return new ODataComparisonExpression(field, "ge", value);
    }
    /** `field lt value` */
    static lt(field, value) {
        return new ODataComparisonExpression(field, "lt", value);
    }
    /** `field le value` */
    static le(field, value) {
        return new ODataComparisonExpression(field, "le", value);
    }
    /** `contains(field,'value')` */
    static contains(field, value) {
        return new ODataFunctionExpression("contains", field, value);
    }
    /** `startswith(field,'value')` */
    static startswith(field, value) {
        return new ODataFunctionExpression("startswith", field, value);
    }
    /** `endswith(field,'value')` */
    static endswith(field, value) {
        return new ODataFunctionExpression("endswith", field, value);
    }
    /** Combines expressions with logical AND, each parenthesized. */
    static and(...parts) {
        return new ODataCompositeExpression("and", parts);
    }
    /** Combines expressions with logical OR, each parenthesized. */
    static or(...parts) {
        return new ODataCompositeExpression("or", parts);
    }
    /** Negates an expression. */
    static not(expression) {
        return new ODataNotExpression(expression);
    }
}
//# sourceMappingURL=ODataFilter.js.map