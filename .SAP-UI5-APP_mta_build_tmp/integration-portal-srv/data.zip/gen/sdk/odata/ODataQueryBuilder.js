/**
 * Fluent builder for OData system query options (architecture: OData Framework, §5). Every SDK
 * list operation builds its query this way rather than assembling `$`-prefixed strings by hand.
 *
 * @example
 * new ODataQueryBuilder()
 *   .top(100)
 *   .skip(0)
 *   .filter(ODataFilter.eq("status", "FAILED"))
 *   .orderBy("startTime", "desc")
 *   .select("messageId", "status", "startTime")
 *   .expand("errorDetails")
 *   .count()
 *   .build();
 */
export class ODataQueryBuilder {
    topValue;
    skipValue;
    filterValue;
    orderByClauses = [];
    selectFields = [];
    expandFields = [];
    countRequested = false;
    /** Sets `$top`. */
    top(value) {
        this.topValue = value;
        return this;
    }
    /** Sets `$skip`. */
    skip(value) {
        this.skipValue = value;
        return this;
    }
    /** Sets `$filter` from a composed {@link ODataFilterExpression}. */
    filter(expression) {
        this.filterValue = expression;
        return this;
    }
    /** Appends an `$orderby` clause. */
    orderBy(field, direction = "asc") {
        this.orderByClauses.push(direction === "desc" ? `${field} desc` : field);
        return this;
    }
    /** Appends field(s) to `$select`. */
    select(...fields) {
        this.selectFields.push(...fields);
        return this;
    }
    /** Appends navigation propert(y/ies) to `$expand`. */
    expand(...fields) {
        this.expandFields.push(...fields);
        return this;
    }
    /** Requests a total count (`$count=true` on v4, `$inlinecount=allpages` on v2). */
    count(value = true) {
        this.countRequested = value;
        return this;
    }
    /**
     * Renders the accumulated options into the query-parameter record an HTTP call sends.
     * @param version target OData version (default `v4`); only affects filter literal rendering and
     *   the count option's parameter name.
     * @returns the `$`-prefixed query parameters.
     */
    build(version = "v4") {
        const params = {};
        if (this.topValue !== undefined) {
            params.$top = this.topValue;
        }
        if (this.skipValue !== undefined) {
            params.$skip = this.skipValue;
        }
        if (this.filterValue !== undefined) {
            params.$filter = this.filterValue.render(version);
        }
        if (this.orderByClauses.length > 0) {
            params.$orderby = this.orderByClauses.join(",");
        }
        if (this.selectFields.length > 0) {
            params.$select = this.selectFields.join(",");
        }
        if (this.expandFields.length > 0) {
            params.$expand = this.expandFields.join(",");
        }
        if (this.countRequested) {
            if (version === "v2") {
                params.$inlinecount = "allpages";
            }
            else {
                params.$count = true;
            }
        }
        return params;
    }
}
//# sourceMappingURL=ODataQueryBuilder.js.map