/**
 * Builds a `multipart/mixed` OData v2 `$batch` request body from a sequence of operations
 * (architecture: OData Framework, §5 — "Batch requests"). Each operation becomes one
 * `application/http` MIME part per the OData batch specification; the boundary is generated fresh
 * per build so concurrent batches never collide.
 */
export class ODataBatchBuilder {
    operations = [];
    /**
     * Adds an operation to the batch.
     * @param operation the operation to include.
     * @returns this builder, for chaining.
     */
    add(operation) {
        this.operations.push(operation);
        return this;
    }
    /**
     * Renders the accumulated operations into a batch request body.
     * @returns the request body and its `Content-Type` (including the boundary parameter).
     * @throws {Error} when no operations were added.
     */
    build() {
        if (this.operations.length === 0) {
            throw new Error("ODataBatchBuilder.build() requires at least one operation.");
        }
        const boundary = `batch_${crypto.randomUUID()}`;
        const lines = [];
        for (const operation of this.operations) {
            lines.push(`--${boundary}`);
            lines.push("Content-Type: application/http");
            lines.push("Content-Transfer-Encoding: binary");
            lines.push("");
            lines.push(`${operation.method} ${operation.url} HTTP/1.1`);
            if (operation.body !== undefined) {
                lines.push("Content-Type: application/json");
                lines.push("");
                lines.push(JSON.stringify(operation.body));
            }
            else {
                lines.push("");
            }
            lines.push("");
        }
        lines.push(`--${boundary}--`);
        return { body: lines.join("\r\n"), contentType: `multipart/mixed;boundary=${boundary}` };
    }
}
//# sourceMappingURL=ODataBatchBuilder.js.map