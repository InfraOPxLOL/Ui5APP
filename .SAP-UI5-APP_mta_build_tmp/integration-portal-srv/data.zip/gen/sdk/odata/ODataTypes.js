export {};
//# sourceMappingURL=ODataTypes.js.map