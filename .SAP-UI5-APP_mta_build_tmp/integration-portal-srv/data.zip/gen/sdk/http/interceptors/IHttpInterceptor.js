export {};
//# sourceMappingURL=IHttpInterceptor.js.map