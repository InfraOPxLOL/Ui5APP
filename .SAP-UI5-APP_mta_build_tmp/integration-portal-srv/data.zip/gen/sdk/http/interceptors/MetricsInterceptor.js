import { httpMetricsRecorder } from "../HttpMetricsRecorder.js";
/**
 * Records request timing/outcome into an {@link HttpMetricsRecorder} (architecture: HTTP
 * Infrastructure, "Metrics", "Performance timings", "Request duration"). Defaults to the
 * process-wide recorder; a dedicated instance may be injected for test isolation.
 */
export class MetricsInterceptor {
    recorder;
    name = "metrics";
    constructor(recorder = httpMetricsRecorder) {
        this.recorder = recorder;
    }
    beforeRequest(options) {
        return options;
    }
    afterResponse(response, context) {
        this.recorder.record({
            method: context.bag.method,
            endpoint: context.bag.endpoint,
            status: response.status,
            durationMs: response.durationMs,
            attempts: response.attempts,
            succeeded: response.ok,
            timestamp: Date.now(),
        });
    }
    onError(_error, context) {
        this.recorder.record({
            method: context.bag.method ?? "UNKNOWN",
            endpoint: context.bag.endpoint ?? context.operationName,
            status: undefined,
            durationMs: context.startedAt !== undefined ? Date.now() - context.startedAt : 0,
            attempts: context.attempt,
            succeeded: false,
            timestamp: Date.now(),
        });
    }
}
//# sourceMappingURL=MetricsInterceptor.js.map