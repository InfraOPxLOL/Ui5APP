/**
 * In-process HTTP performance metrics recorder (architecture: "Metrics", "Performance timings",
 * "Request duration", §1/§13).
 *
 * Purely in-memory and per-instance — consistent with the stateless-backend constraint, this is
 * observability for the current process, not a persisted metrics store. A production deployment
 * would additionally export these samples to an APM/metrics backend; that exporter is a documented
 * future extension point (`export()`), not implemented here.
 */
export class HttpMetricsRecorder {
    samples = [];
    maxSamples;
    constructor(maxSamples = 1000) {
        this.maxSamples = maxSamples;
    }
    /**
     * Records one completed call.
     * @param sample the timing/outcome sample.
     */
    record(sample) {
        this.samples.push(sample);
        if (this.samples.length > this.maxSamples) {
            this.samples.shift();
        }
    }
    /**
     * @param endpoint optional endpoint filter (host + path).
     * @returns the raw recorded samples, most recent last.
     */
    getSamples(endpoint) {
        return endpoint === undefined
            ? [...this.samples]
            : this.samples.filter((sample) => sample.endpoint === endpoint);
    }
    /**
     * Aggregates recorded samples per endpoint.
     * @returns per-endpoint timing statistics.
     */
    getStats() {
        const byEndpoint = new Map();
        for (const sample of this.samples) {
            const bucket = byEndpoint.get(sample.endpoint) ?? [];
            bucket.push(sample);
            byEndpoint.set(sample.endpoint, bucket);
        }
        return Array.from(byEndpoint.entries()).map(([endpoint, samples]) => HttpMetricsRecorder.aggregate(endpoint, samples));
    }
    /** Clears all recorded samples. */
    reset() {
        this.samples.length = 0;
    }
    static aggregate(endpoint, samples) {
        const durations = samples.map((sample) => sample.durationMs);
        const totalDurationMs = durations.reduce((sum, value) => sum + value, 0);
        return {
            endpoint,
            count: samples.length,
            errorCount: samples.filter((sample) => !sample.succeeded).length,
            totalDurationMs,
            minDurationMs: Math.min(...durations),
            maxDurationMs: Math.max(...durations),
            averageDurationMs: totalDurationMs / samples.length,
        };
    }
}
/** Process-wide HTTP metrics recorder shared by every SDK HTTP client instance. */
export const httpMetricsRecorder = new HttpMetricsRecorder();
//# sourceMappingURL=HttpMetricsRecorder.js.map