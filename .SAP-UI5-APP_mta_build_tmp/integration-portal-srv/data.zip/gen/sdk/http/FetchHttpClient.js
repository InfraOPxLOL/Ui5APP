import { DEFAULT_RETRY_POLICY, } from "./HttpTypes.js";
import { RetryExecutor } from "./RetryExecutor.js";
import { HttpErrorTranslator } from "../errors/HttpErrorTranslator.js";
/**
 * The SDK's concrete {@link IHttpClient}, built on the platform `fetch` global.
 *
 * Owns everything the HTTP Infrastructure mandate requires (§1): connection/request timeout with
 * cancellation, retry with exponential backoff, compression negotiation, JSON/XML/multipart/binary
 * body encoding, the interceptor chain (correlation id, logging, metrics — see `interceptors/`),
 * and streaming responses. This is the *only* class in the SDK that calls the platform `fetch`;
 * every higher layer (REST, OData, providers) goes through an `IHttpClient` instance.
 */
export class FetchHttpClient {
    defaultTimeoutMs;
    defaultRetryPolicy;
    interceptors;
    constructor(options = {}) {
        this.defaultTimeoutMs = options.defaultTimeoutMs ?? 30000;
        this.defaultRetryPolicy = options.defaultRetryPolicy ?? DEFAULT_RETRY_POLICY;
        this.interceptors = options.interceptors ?? [];
    }
    /** @inheritdoc */
    async execute(options, context) {
        context.startedAt = Date.now();
        const policy = { ...this.defaultRetryPolicy, ...options.retry };
        const endpoint = FetchHttpClient.endpointOf(options.url);
        context.bag.method = options.method;
        context.bag.endpoint = endpoint;
        const requestAfterBefore = await this.runBeforeRequest(options, context);
        const { attempts, result, error } = await RetryExecutor.run(policy, async (attemptNumber) => {
            context.attempt = attemptNumber;
            return this.attemptOnce(requestAfterBefore, policy);
        });
        if (result !== undefined) {
            const finalResponse = {
                ...result,
                attempts,
                durationMs: Date.now() - context.startedAt,
            };
            await this.runAfterResponse(finalResponse, context);
            return finalResponse;
        }
        await this.runOnError(error, context);
        throw error;
    }
    async attemptOnce(options, policy) {
        const timeoutMs = options.timeoutMs ?? this.defaultTimeoutMs;
        const timeoutController = new AbortController();
        const timer = setTimeout(() => timeoutController.abort(), timeoutMs);
        const combinedSignal = FetchHttpClient.mergeSignals(options.signal, timeoutController.signal);
        const attemptStart = Date.now();
        try {
            const fetchResponse = await fetch(FetchHttpClient.buildUrl(options), {
                method: options.method,
                headers: FetchHttpClient.buildHeaders(options),
                body: FetchHttpClient.encodeBody(options.body),
                signal: combinedSignal,
            });
            const durationMs = Date.now() - attemptStart;
            const response = await FetchHttpClient.toHttpResponse(fetchResponse, options, durationMs);
            const retryable = !response.ok && RetryExecutor.isRetryableStatus(policy, response.status);
            return { result: response, status: response.status, retryable };
        }
        catch (cause) {
            const isOurTimeout = timeoutController.signal.aborted;
            const translated = HttpErrorTranslator.translateTransportFailure(isOurTimeout ? "timeout" : "network", isOurTimeout ? timeoutMs : cause);
            return { error: translated, retryable: policy.retryOnNetworkError };
        }
        finally {
            clearTimeout(timer);
        }
    }
    async runBeforeRequest(options, context) {
        let current = options;
        for (const interceptor of this.interceptors) {
            if (interceptor.beforeRequest !== undefined) {
                current = await interceptor.beforeRequest(current, context);
            }
        }
        return current;
    }
    async runAfterResponse(response, context) {
        for (const interceptor of [...this.interceptors].reverse()) {
            await interceptor.afterResponse?.(response, context);
        }
    }
    async runOnError(error, context) {
        for (const interceptor of [...this.interceptors].reverse()) {
            await interceptor.onError?.(error, context);
        }
    }
    static buildUrl(options) {
        if (options.query === undefined) {
            return options.url;
        }
        const search = new URLSearchParams();
        for (const [key, value] of Object.entries(options.query)) {
            if (value !== undefined) {
                search.append(key, String(value));
            }
        }
        const qs = search.toString();
        return qs === "" ? options.url : `${options.url}${options.url.includes("?") ? "&" : "?"}${qs}`;
    }
    static buildHeaders(options) {
        const headers = { ...options.headers };
        if (options.compress !== false) {
            headers["Accept-Encoding"] = "gzip, br";
        }
        if (options.body !== undefined) {
            headers["Content-Type"] ??= FetchHttpClient.contentTypeFor(options.body);
        }
        return headers;
    }
    static contentTypeFor(body) {
        switch (body.encoding) {
            case "json":
                return "application/json";
            case "xml":
                return "application/xml";
            case "text":
                return "text/plain";
            case "binary":
                return "application/octet-stream";
            case "multipart":
                // The boundary is generated by FormData itself; no explicit Content-Type header is set for
                // multipart bodies (the platform fetch implementation supplies its own with a boundary).
                return "";
            default:
                return "application/octet-stream";
        }
    }
    static encodeBody(body) {
        if (body === undefined) {
            return undefined;
        }
        switch (body.encoding) {
            case "json":
                return JSON.stringify(body.value);
            case "xml":
            case "text":
                return body.value;
            case "binary":
                return body.value instanceof Uint8Array ? body.value : new Uint8Array(body.value);
            case "multipart": {
                const form = new FormData();
                for (const field of body.value) {
                    if (typeof field.value === "string") {
                        form.append(field.name, field.value);
                    }
                    else {
                        form.append(field.name, field.value, field.fileName);
                    }
                }
                return form;
            }
            default:
                return undefined;
        }
    }
    static async toHttpResponse(response, options, durationMs) {
        const headers = new Map();
        response.headers.forEach((value, key) => headers.set(key, value));
        const base = {
            status: response.status,
            headers,
            ok: response.ok,
            attempts: 1,
            durationMs,
        };
        if (options.stream === true && response.body !== null) {
            return { ...base, bodyStream: response.body };
        }
        if (options.binaryResponse === true) {
            return { ...base, bodyBinary: new Uint8Array(await response.arrayBuffer()) };
        }
        return { ...base, bodyText: await response.text() };
    }
    static mergeSignals(a, b) {
        if (a === undefined) {
            return b;
        }
        const merged = new AbortController();
        const abort = () => merged.abort();
        if (a.aborted || b.aborted) {
            merged.abort();
        }
        else {
            a.addEventListener("abort", abort, { once: true });
            b.addEventListener("abort", abort, { once: true });
        }
        return merged.signal;
    }
    static endpointOf(url) {
        try {
            const parsed = new URL(url);
            return `${parsed.host}${parsed.pathname}`;
        }
        catch {
            return url;
        }
    }
}
//# sourceMappingURL=FetchHttpClient.js.map