/** The default retry policy applied when a request specifies none. */
export const DEFAULT_RETRY_POLICY = {
    maxAttempts: 3,
    baseDelayMs: 200,
    backoffFactor: 2,
    maxDelayMs: 5000,
    retryableStatusCodes: [429, 500, 502, 503, 504],
    retryOnNetworkError: true,
};
//# sourceMappingURL=HttpTypes.js.map