/**
 * The default {@link IDestinationDiscoveryProvider}: an in-memory, caller-supplied list of
 * destinations. Suitable for configuration-driven destination lists (today's use) and for tests;
 * swap in a different provider (e.g. one backed by a live Destination-service lookup) without
 * touching {@link DestinationResolver}.
 */
export class StaticDestinationDiscoveryProvider {
    definitions;
    constructor(definitions) {
        this.definitions = definitions;
    }
    /** @inheritdoc */
    listDestinations() {
        return Promise.resolve(this.definitions);
    }
}
//# sourceMappingURL=StaticDestinationDiscoveryProvider.js.map