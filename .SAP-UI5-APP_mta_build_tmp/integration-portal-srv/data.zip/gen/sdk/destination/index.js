export { StaticDestinationDiscoveryProvider } from "./StaticDestinationDiscoveryProvider.js";
export { BtpDestinationDiscoveryProvider, } from "./BtpDestinationDiscoveryProvider.js";
export { DestinationResolver } from "./DestinationResolver.js";
//# sourceMappingURL=index.js.map