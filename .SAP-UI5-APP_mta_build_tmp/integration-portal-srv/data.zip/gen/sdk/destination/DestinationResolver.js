import { AuthProviderFactory } from "../auth/AuthProviderFactory.js";
import { ConfigurationError } from "../../core/errors/ConfigurationError.js";
/**
 * The SDK's destination resolver (architecture: Destination Framework, §3).
 *
 * Delegates *which* destinations exist to an {@link IDestinationDiscoveryProvider} (today: a
 * static list; tomorrow: a live lookup) and *how to authenticate* each one to the Authentication
 * Framework — this class only does the resolution and auth-provider lifecycle management (one
 * provider instance per tenant, cached, so token caches persist across calls).
 */
export class DestinationResolver {
    discovery;
    httpClient;
    authProviders = new Map();
    constructor(discovery, httpClient) {
        this.discovery = discovery;
        this.httpClient = httpClient;
    }
    /** @inheritdoc */
    async resolve(options) {
        const definition = await this.findDefinition(options.tenantId);
        const provider = this.getOrCreateAuthProvider(definition);
        const headers = await provider.getAuthHeaders({
            tenantId: definition.tenantId,
            correlationId: options.correlationId,
        });
        return {
            tenantId: definition.tenantId,
            baseUrl: definition.baseUrl,
            headers,
            destinationName: definition.destinationName,
        };
    }
    /** @inheritdoc */
    async listEnvironments() {
        const definitions = await this.discovery.listDestinations();
        return Array.from(new Set(definitions.map((definition) => definition.environment)));
    }
    async findDefinition(tenantId) {
        const definitions = await this.discovery.listDestinations();
        const definition = tenantId !== undefined
            ? definitions.find((candidate) => candidate.tenantId === tenantId)
            : (definitions.find((candidate) => candidate.default) ?? definitions[0]);
        if (definition === undefined) {
            throw new ConfigurationError(`No destination is configured for tenant "${tenantId ?? "(default)"}".`);
        }
        return definition;
    }
    getOrCreateAuthProvider(definition) {
        let provider = this.authProviders.get(definition.tenantId);
        if (provider === undefined) {
            provider = AuthProviderFactory.create(definition.authConfig, this.httpClient);
            this.authProviders.set(definition.tenantId, provider);
        }
        return provider;
    }
}
//# sourceMappingURL=DestinationResolver.js.map