export {};
//# sourceMappingURL=DestinationTypes.js.map