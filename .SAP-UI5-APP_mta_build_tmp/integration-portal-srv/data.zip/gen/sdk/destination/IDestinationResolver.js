export {};
//# sourceMappingURL=IDestinationResolver.js.map