export {};
//# sourceMappingURL=IDestinationDiscoveryProvider.js.map