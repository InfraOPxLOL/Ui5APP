import { generatePayloadAttachments } from "../mock/fixtures/index.js";
/** Mock implementation of {@link IPayloadProvider} (architecture: Provider Framework, §10). */
export class MockPayloadProvider {
    mockEngine;
    constructor(mockEngine) {
        this.mockEngine = mockEngine;
    }
    /** @inheritdoc */
    async listAttachments(context, messageId) {
        const attachments = await this.mockEngine.resolve({
            operationKey: "payload.listAttachments",
            tenantId: context.tenantId,
            generateSuccess: () => generatePayloadAttachments(messageId, 1),
            generateEmpty: () => [],
        });
        return attachments.map(({ content: _content, ...metadata }) => metadata);
    }
    /** @inheritdoc */
    async getAttachment(context, messageId, attachmentId) {
        const attachments = await this.mockEngine.resolve({
            operationKey: "payload.getAttachment",
            tenantId: context.tenantId,
            generateSuccess: () => generatePayloadAttachments(messageId, 1),
        });
        // Generated attachment ids are opaque random hex a caller cannot predict ahead of a listing
        // call; fall back to the first generated attachment so any id round-tripped from
        // listAttachments() resolves, matching how a real store would behave for a real id.
        return (attachments.find((attachment) => attachment.attachmentId === attachmentId) ?? attachments[0]);
    }
}
//# sourceMappingURL=MockPayloadProvider.js.map