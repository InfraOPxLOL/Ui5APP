import { ODataClient } from "../odata/ODataClient.js";
import { ODataQueryBuilder } from "../odata/ODataQueryBuilder.js";
import { toODataV2KeyLiteral } from "./RealProviderSupport.js";
const DEFAULT_VALUE_MAPPING_ENDPOINTS = {
    schemesEntitySet: "ValueMappingDesigntimeArtifacts",
};
/**
 * Live implementation of {@link IValueMappingProvider} (architecture: Value Mapping Provider, §10 —
 * "Read only. No editing.").
 *
 * SAP Integration Suite's public API surface for Value Mapping exposes design-time artifact
 * *metadata* (scheme name/description) but not per-entry mapping content without downloading and
 * unpacking the deployed artifact's content archive — out of scope for a REST/OData-only client.
 * Schemes are therefore returned with an accurate `name`/`description` and an empty `agencies` list;
 * this is a documented real-world limitation, not a bug — a future phase can populate `agencies` by
 * adding artifact-content parsing without changing this contract.
 */
export class RealValueMappingProvider {
    pipeline;
    endpoints;
    odataClient;
    constructor(pipeline, httpClient, endpoints = DEFAULT_VALUE_MAPPING_ENDPOINTS) {
        this.pipeline = pipeline;
        this.endpoints = endpoints;
        this.odataClient = new ODataClient(httpClient, "v2");
    }
    /** @inheritdoc */
    async listSchemes(context) {
        return this.pipeline.run({
            operationName: "valueMapping.listSchemes",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const items = await this.odataClient.queryAllPages(`${tenant.baseUrl}/${this.endpoints.schemesEntitySet}`, new ODataQueryBuilder(), tenant, opContext);
                return items.map(RealValueMappingProvider.toDomain);
            },
        });
    }
    /** @inheritdoc */
    async getScheme(context, schemeName) {
        return this.pipeline.run({
            operationName: "valueMapping.getScheme",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const raw = await this.odataClient.getEntity(`${tenant.baseUrl}/${this.endpoints.schemesEntitySet}(${toODataV2KeyLiteral(schemeName)})`, tenant, opContext);
                return raw === undefined ? undefined : RealValueMappingProvider.toDomain(raw);
            },
        });
    }
    static toDomain(raw) {
        return { name: raw.Name, description: raw.Description, agencies: [] };
    }
}
//# sourceMappingURL=RealValueMappingProvider.js.map