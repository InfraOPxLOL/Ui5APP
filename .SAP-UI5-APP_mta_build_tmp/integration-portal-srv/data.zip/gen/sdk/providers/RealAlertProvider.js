import { SdkRestClient } from "../rest/SdkRestClient.js";
import { createOperationContext } from "../models/OperationContext.js";
import { createRequestContext } from "../models/RequestContext.js";
import { HttpError } from "../../core/errors/HttpError.js";
/**
 * Live implementation of {@link IAlertProvider}, backed by the SAP Alert Notification Service's
 * documented consumer REST API (architecture: Alert Provider, §11 — "Alert Notification retrieval").
 * Reads via {@link SdkRestClient} directly (JSON REST, not OData) rather than the pipeline/
 * destination-resolver seam the CPI-tenant providers use, per {@link AlertNotificationServiceConfig}'s
 * doc comment. When {@link AlertNotificationServiceConfig} is not configured, the SDK composition
 * root simply does not construct this provider — the platform's local alert sweeps remain the only
 * source, matching {@link IAlertProvider}'s "implementations may fan in multiple sources" contract.
 */
export class RealAlertProvider {
    ans;
    restClient;
    constructor(httpClient, ans) {
        this.ans = ans;
        this.restClient = new SdkRestClient(httpClient);
    }
    /** @inheritdoc */
    async queryAlerts(context, page, severity) {
        const opContext = this.buildContext(context, "alert.queryAlerts");
        const authHeaders = await this.ans.authProvider.getAuthHeaders({
            tenantId: context.tenantId,
            correlationId: context.correlationId,
        });
        const pageSize = Math.max(page.top, 1);
        const response = await this.restClient.get(`${this.ans.baseUrl}/api/v1/consumer/alerts`, opContext, {
            headers: authHeaders,
            query: {
                pageSize,
                pageNum: Math.floor(page.skip / pageSize) + 1,
                ...(severity !== undefined ? { severity } : {}),
            },
        });
        const alerts = response.data.alerts ?? [];
        return {
            items: alerts.map(RealAlertProvider.toDomain),
            total: response.data.totalHits ?? alerts.length,
        };
    }
    /** @inheritdoc */
    async getAlert(context, alertId) {
        const opContext = this.buildContext(context, "alert.getAlert");
        const authHeaders = await this.ans.authProvider.getAuthHeaders({
            tenantId: context.tenantId,
            correlationId: context.correlationId,
        });
        try {
            const response = await this.restClient.get(`${this.ans.baseUrl}/api/v1/consumer/alerts/${encodeURIComponent(alertId)}`, opContext, { headers: authHeaders });
            return RealAlertProvider.toDomain(response.data);
        }
        catch (error) {
            if (error instanceof HttpError && error.statusCode === 404) {
                return undefined;
            }
            throw error;
        }
    }
    buildContext(context, operationName) {
        return createOperationContext(createRequestContext(context.tenantId, { correlationId: context.correlationId }), operationName);
    }
    static toDomain(raw) {
        return {
            alertId: raw.id,
            severity: raw.severity ?? "INFO",
            title: raw.subject ?? "",
            description: raw.body ?? "",
            source: raw.resource?.resourceName ?? "SAP Alert Notification Service",
            raisedAt: raw.eventTime ?? new Date().toISOString(),
            tags: raw.tags !== undefined
                ? Object.entries(raw.tags).map(([key, value]) => `${key}=${value}`)
                : [],
        };
    }
}
//# sourceMappingURL=RealAlertProvider.js.map