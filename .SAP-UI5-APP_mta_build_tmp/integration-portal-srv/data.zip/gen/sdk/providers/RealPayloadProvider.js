import { ODataClient } from "../odata/ODataClient.js";
import { ODataQueryBuilder } from "../odata/ODataQueryBuilder.js";
import { SdkRestClient } from "../rest/SdkRestClient.js";
import { toODataV2KeyLiteral } from "./RealProviderSupport.js";
/** Content-type prefixes/values downloaded as UTF-8 text rather than base64 — matches {@link PayloadEnvelope.content}'s documented contract ("the payload body as text; binary payloads are base64-encoded"). */
const TEXT_CONTENT_TYPES = [
    "text/",
    "application/xml",
    "application/json",
    "application/soap+xml",
    "application/xhtml+xml",
];
function isTextContentType(contentType) {
    const normalized = contentType.toLowerCase();
    return TEXT_CONTENT_TYPES.some((candidate) => normalized.startsWith(candidate));
}
/**
 * Live implementation of {@link IPayloadProvider}, backed by SAP Integration Suite's documented
 * `MessageProcessingLogs('id')/Attachments` navigation and the `MessageProcessingLogAttachments`
 * entity set's `$value` binary stream (architecture: Payload Provider, §7). Text content types
 * (XML/JSON/plain text — the common case for integration payloads) are decoded as UTF-8 text;
 * genuinely binary content types are base64-encoded — matching {@link PayloadEnvelope.content}'s
 * documented contract exactly (and `MockPayloadProvider`'s fixture behaviour, so callers see the
 * same shape from either implementation).
 */
export class RealPayloadProvider {
    pipeline;
    odataClient;
    restClient;
    constructor(pipeline, httpClient) {
        this.pipeline = pipeline;
        this.odataClient = new ODataClient(httpClient, "v2");
        this.restClient = new SdkRestClient(httpClient);
    }
    /** @inheritdoc */
    async listAttachments(context, messageId) {
        return this.pipeline.run({
            operationName: "payload.listAttachments",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const items = await this.odataClient.queryAllPages(`${tenant.baseUrl}/MessageProcessingLogs(${toODataV2KeyLiteral(messageId)})/Attachments`, new ODataQueryBuilder(), tenant, opContext);
                return items.map((raw) => RealPayloadProvider.toMetadata(messageId, raw));
            },
        });
    }
    /** @inheritdoc */
    async getAttachment(context, messageId, attachmentId) {
        return this.pipeline.run({
            operationName: "payload.getAttachment",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const entityUrl = `${tenant.baseUrl}/MessageProcessingLogAttachments(${toODataV2KeyLiteral(attachmentId)})`;
                const metadata = await this.odataClient.getEntity(entityUrl, tenant, opContext);
                if (metadata === undefined) {
                    return undefined;
                }
                const binary = await this.restClient.getBinary(`${entityUrl}/$value`, opContext, {
                    headers: tenant.headers,
                });
                const content = isTextContentType(metadata.ContentType)
                    ? Buffer.from(binary.data).toString("utf8")
                    : Buffer.from(binary.data).toString("base64");
                return {
                    messageId,
                    attachmentId,
                    name: metadata.Name,
                    contentType: metadata.ContentType,
                    sizeBytes: metadata.ContentLength,
                    content,
                };
            },
        });
    }
    static toMetadata(messageId, raw) {
        return {
            messageId,
            attachmentId: raw.AttachmentId,
            name: raw.Name,
            contentType: raw.ContentType,
            sizeBytes: raw.ContentLength,
        };
    }
}
//# sourceMappingURL=RealPayloadProvider.js.map