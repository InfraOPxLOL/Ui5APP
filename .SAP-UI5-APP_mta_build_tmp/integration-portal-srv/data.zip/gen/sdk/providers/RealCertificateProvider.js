import { ODataClient } from "../odata/ODataClient.js";
import { ODataQueryBuilder } from "../odata/ODataQueryBuilder.js";
import { parseODataV2DateTime } from "./RealProviderSupport.js";
/**
 * Live implementation of {@link ICertificateProvider}, backed by SAP Integration Suite's
 * `KeystoreEntries` OData entity set (architecture: Certificate Provider, §9). Read-only, matching
 * the Phase-3 contract; the expiry sweep filters/sorts over the same fetched list the mock
 * implementation does, just populated from a real tenant.
 */
export class RealCertificateProvider {
    pipeline;
    odataClient;
    constructor(pipeline, httpClient) {
        this.pipeline = pipeline;
        this.odataClient = new ODataClient(httpClient, "v2");
    }
    /** @inheritdoc */
    async listCertificates(context) {
        return this.pipeline.run({
            operationName: "certificate.listCertificates",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const items = await this.odataClient.queryAllPages(`${tenant.baseUrl}/KeystoreEntries`, new ODataQueryBuilder(), tenant, opContext);
                return items.map(RealCertificateProvider.toDomain);
            },
        });
    }
    /** @inheritdoc */
    async listExpiring(context, withinDays) {
        return this.pipeline.run({
            operationName: "certificate.listExpiring",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const items = await this.odataClient.queryAllPages(`${tenant.baseUrl}/KeystoreEntries`, new ODataQueryBuilder(), tenant, opContext);
                const horizon = Date.now() + withinDays * 86400000;
                return items
                    .map(RealCertificateProvider.toDomain)
                    .filter((certificate) => new Date(certificate.validTo).getTime() <= horizon)
                    .sort((a, b) => new Date(a.validTo).getTime() - new Date(b.validTo).getTime());
            },
        });
    }
    static toDomain(raw) {
        return {
            alias: raw.Alias,
            keyType: raw.Type,
            owner: raw.Owner,
            issuer: raw.Issuer,
            validFrom: parseODataV2DateTime(raw.ValidFrom) ?? "",
            validTo: parseODataV2DateTime(raw.ValidTo) ?? "",
            serialNumber: raw.SerialNumber,
        };
    }
}
//# sourceMappingURL=RealCertificateProvider.js.map