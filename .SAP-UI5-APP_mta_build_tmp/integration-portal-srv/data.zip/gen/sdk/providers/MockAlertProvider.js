import { generateAlerts } from "../mock/fixtures/index.js";
/** Mock implementation of {@link IAlertProvider} (architecture: Provider Framework, §10). */
export class MockAlertProvider {
    mockEngine;
    constructor(mockEngine) {
        this.mockEngine = mockEngine;
    }
    /** @inheritdoc */
    async queryAlerts(context, page, severity) {
        const all = await this.mockEngine.resolve({
            operationKey: "alert.queryAlerts",
            tenantId: context.tenantId,
            generateSuccess: () => generateAlerts(30),
            generateEmpty: () => [],
            generateLarge: () => generateAlerts(250),
        });
        const filtered = severity !== undefined ? all.filter((alert) => alert.severity === severity) : all;
        return { items: filtered.slice(page.skip, page.skip + page.top), total: filtered.length };
    }
    /** @inheritdoc */
    async getAlert(context, alertId) {
        const all = await this.mockEngine.resolve({
            operationKey: "alert.getAlert",
            tenantId: context.tenantId,
            generateSuccess: () => generateAlerts(30),
        });
        return all.find((alert) => alert.alertId === alertId) ?? all[0];
    }
}
//# sourceMappingURL=MockAlertProvider.js.map