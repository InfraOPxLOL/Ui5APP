import { ODataClient } from "../odata/ODataClient.js";
import { ODataQueryBuilder } from "../odata/ODataQueryBuilder.js";
import { SdkRestClient } from "../rest/SdkRestClient.js";
import { HttpError } from "../../core/errors/HttpError.js";
import { parseODataV2DateTime, toODataV2KeyLiteral } from "./RealProviderSupport.js";
/**
 * Live implementation of {@link IRuntimeProvider}, backed by SAP Integration Suite's documented
 * OData v1 Monitoring API (`IntegrationRuntimeArtifacts`) and its `DeployIntegrationDesigntimeArtifact`
 * deploy action (architecture: Runtime Provider, §8). `restartArtifact` reads the artifact's current
 * version, then redeploys it — CPI has no separate "restart" verb; requesting a fresh deploy of the
 * already-deployed version is the documented equivalent.
 */
export class RealRuntimeProvider {
    pipeline;
    odataClient;
    restClient;
    constructor(pipeline, httpClient) {
        this.pipeline = pipeline;
        this.odataClient = new ODataClient(httpClient, "v2");
        this.restClient = new SdkRestClient(httpClient);
    }
    /** @inheritdoc */
    async listArtifacts(context) {
        return this.pipeline.run({
            operationName: "runtime.listArtifacts",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const items = await this.odataClient.queryAllPages(`${tenant.baseUrl}/IntegrationRuntimeArtifacts`, new ODataQueryBuilder(), tenant, opContext);
                return items.map(RealRuntimeProvider.toDomain);
            },
        });
    }
    /** @inheritdoc */
    async getArtifact(context, artifactId) {
        return this.pipeline.run({
            operationName: "runtime.getArtifact",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const raw = await this.fetchArtifact(artifactId, tenant, opContext);
                return raw === undefined ? undefined : RealRuntimeProvider.toDomain(raw);
            },
        });
    }
    /** @inheritdoc */
    async restartArtifact(context, artifactId) {
        return this.pipeline.run({
            operationName: "runtime.restartArtifact",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const raw = await this.fetchArtifact(artifactId, tenant, opContext);
                if (raw === undefined) {
                    throw HttpError.notFound(`Runtime artifact "${artifactId}" is not deployed.`);
                }
                await this.restClient.post(`${tenant.baseUrl}/DeployIntegrationDesigntimeArtifact`, undefined, opContext, {
                    headers: tenant.headers,
                    query: { Id: toODataV2KeyLiteral(raw.Id), Version: toODataV2KeyLiteral(raw.Version) },
                });
            },
        });
    }
    fetchArtifact(artifactId, tenant, opContext) {
        return this.odataClient.getEntity(`${tenant.baseUrl}/IntegrationRuntimeArtifacts(${toODataV2KeyLiteral(artifactId)})`, tenant, opContext);
    }
    static toDomain(raw) {
        return {
            artifactId: raw.Id,
            name: raw.Name,
            type: raw.Type,
            version: raw.Version,
            status: raw.Status,
            deployedOn: parseODataV2DateTime(raw.DeployedOn),
            deployedBy: raw.DeployedBy,
            errorText: raw.ErrorInformation,
        };
    }
}
//# sourceMappingURL=RealRuntimeProvider.js.map