import { generateQueueStates, generateQueuedMessages, generateSingleMessage, recordMockMove, MOCK_DISCOVERED_QUEUE_NAMES, } from "../mock/fixtures/index.js";
/** Mock implementation of {@link IJmsProvider} (architecture: Provider Framework, §10). */
export class MockJmsProvider {
    mockEngine;
    constructor(mockEngine) {
        this.mockEngine = mockEngine;
    }
    /** @inheritdoc */
    async getQueueStates(context, queueNames) {
        return this.mockEngine.resolve({
            operationKey: "jms.getQueueStates",
            tenantId: context.tenantId,
            generateSuccess: () => generateQueueStates(queueNames),
            generateEmpty: () => [],
        });
    }
    /** @inheritdoc */
    async discoverQueues(context) {
        return this.mockEngine.resolve({
            operationKey: "jms.discoverQueues",
            tenantId: context.tenantId,
            generateSuccess: () => generateQueueStates(MOCK_DISCOVERED_QUEUE_NAMES),
            generateEmpty: () => [],
        });
    }
    /** @inheritdoc */
    async listMessages(context, queueName, page) {
        const all = await this.mockEngine.resolve({
            operationKey: "jms.listMessages",
            tenantId: context.tenantId,
            generateSuccess: () => generateQueuedMessages(queueName, 30),
            generateEmpty: () => [],
            generateLarge: () => generateQueuedMessages(queueName, 250),
        });
        return { items: all.slice(page.skip, page.skip + page.top), total: all.length };
    }
    /** @inheritdoc */
    async deleteMessage(context, queueName, messageId) {
        await this.mockEngine.resolve({
            operationKey: "jms.deleteMessage",
            tenantId: context.tenantId,
            generateSuccess: () => ({ queueName, messageId }),
        });
    }
    /** @inheritdoc */
    async purgeQueue(context, queueName) {
        const messages = await this.mockEngine.resolve({
            operationKey: "jms.purgeQueue",
            tenantId: context.tenantId,
            generateSuccess: () => generateQueuedMessages(queueName, 12),
            generateEmpty: () => [],
        });
        return messages.length;
    }
    /** @inheritdoc */
    async retryMessage(context, queueName, messageId) {
        await this.mockEngine.resolve({
            operationKey: "jms.retryMessage",
            tenantId: context.tenantId,
            generateSuccess: () => ({ queueName, messageId }),
        });
    }
    /**
     * @inheritdoc
     *
     * Records the relocation in the fixture ledger on success, so the caller's verification step
     * (`getMessage` on the target queue) genuinely observes the move — without that, mock mode could
     * never exercise the move → verify → retry sequence. A failure scenario short-circuits before the
     * ledger is touched, leaving the message where it was.
     */
    async moveMessages(context, sourceQueue, targetQueue, messageIds) {
        await this.mockEngine.resolve({
            operationKey: "jms.moveMessages",
            tenantId: context.tenantId,
            generateSuccess: () => ({ sourceQueue, targetQueue, messageIds }),
        });
        recordMockMove(targetQueue, messageIds);
    }
    /** @inheritdoc */
    async getMessage(context, queueName, messageId) {
        return this.mockEngine.resolve({
            operationKey: "jms.getMessage",
            tenantId: context.tenantId,
            generateSuccess: () => generateSingleMessage(queueName, messageId),
            generateEmpty: () => undefined,
        });
    }
}
//# sourceMappingURL=MockJmsProvider.js.map