import { generateSplunkHecEvent } from "../mock/fixtures/index.js";
import { decodeGzipBase64Text } from "./SplunkPayloadCodec.js";
/** Mock implementation of {@link ISplunkProvider} (architecture: Provider Framework, §10). */
export class MockSplunkProvider {
    mockEngine;
    constructor(mockEngine) {
        this.mockEngine = mockEngine;
    }
    /** @inheritdoc */
    async getMessageEvent(context, messageId, hint) {
        const raw = await this.mockEngine.resolve({
            operationKey: "splunk.getMessageEvent",
            tenantId: context.tenantId,
            generateSuccess: () => generateSplunkHecEvent(messageId, hint),
            generateEmpty: () => undefined,
        });
        return raw === undefined ? undefined : MockSplunkProvider.toDomain(messageId, raw);
    }
    static toDomain(messageId, raw) {
        return {
            messageId,
            correlationId: raw.event.correlationId,
            requestPayload: MockSplunkProvider.toBody(raw.event.requestPayload, raw.event.requestPayloadMimeType, raw.event.requestPayloadCompression),
            responsePayload: MockSplunkProvider.toBody(raw.event.responsePayload, raw.event.responsePayloadMimeType, raw.event.responsePayloadCompression),
        };
    }
    static toBody(gzipBase64, contentType, compression) {
        if (gzipBase64 === "") {
            return undefined;
        }
        try {
            const content = decodeGzipBase64Text(gzipBase64);
            return { content, contentType, sizeBytes: Buffer.byteLength(content, "utf8"), compression };
        }
        catch {
            // Malformed compressed data degrades to "unavailable" rather than failing the whole request —
            // matches this codebase's honest-degradation convention (e.g. `PayloadEngine.safeParseJson`).
            return undefined;
        }
    }
}
//# sourceMappingURL=MockSplunkProvider.js.map