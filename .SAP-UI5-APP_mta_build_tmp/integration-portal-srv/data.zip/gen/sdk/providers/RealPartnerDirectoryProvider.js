import { ODataClient } from "../odata/ODataClient.js";
import { ODataQueryBuilder } from "../odata/ODataQueryBuilder.js";
import { ODataFilter } from "../odata/ODataFilter.js";
import { SdkRestClient } from "../rest/SdkRestClient.js";
import { parseODataV2DateTime, toODataV2KeyLiteral } from "./RealProviderSupport.js";
/**
 * Live implementation of {@link IPartnerDirectoryProvider}, backed by SAP Integration Suite's
 * Partner Directory `StringParameters` OData v2 entity set (key `(Pid, Id)`), confirmed present in
 * the tenant `$metadata`.
 *
 * Writes (POST/PUT) require a CSRF token on CPI: every write first performs a
 * `X-CSRF-Token: Fetch` handshake against the service root and replays the returned token (and any
 * session cookie) on the modifying request — handled here so no engine/module ever sees a token.
 */
export class RealPartnerDirectoryProvider {
    pipeline;
    httpClient;
    odataClient;
    restClient;
    constructor(pipeline, httpClient) {
        this.pipeline = pipeline;
        this.httpClient = httpClient;
        this.odataClient = new ODataClient(httpClient, "v2");
        this.restClient = new SdkRestClient(httpClient);
    }
    /** @inheritdoc */
    async getStringParameter(context, pid, id) {
        return this.pipeline.run({
            operationName: "partnerDirectory.getStringParameter",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const raw = await this.odataClient.getEntity(this.parameterUrl(tenant, pid, id), tenant, opContext);
                return raw === undefined ? undefined : RealPartnerDirectoryProvider.toDomain(raw);
            },
        });
    }
    /** @inheritdoc */
    async listStringParameters(context, pid) {
        return this.pipeline.run({
            operationName: "partnerDirectory.listStringParameters",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const items = await this.odataClient.queryAllPages(`${tenant.baseUrl}/StringParameters`, new ODataQueryBuilder().filter(ODataFilter.eq("Pid", pid)), tenant, opContext);
                return items.map(RealPartnerDirectoryProvider.toDomain);
            },
        });
    }
    /** @inheritdoc */
    async upsertStringParameter(context, parameter) {
        return this.pipeline.run({
            operationName: "partnerDirectory.upsertStringParameter",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const existing = await this.odataClient.getEntity(this.parameterUrl(tenant, parameter.pid, parameter.id), tenant, opContext);
                const csrf = await this.fetchCsrf(tenant, opContext);
                const headers = RealPartnerDirectoryProvider.writeHeaders(tenant, csrf);
                const body = { Pid: parameter.pid, Id: parameter.id, Value: parameter.value };
                if (existing === undefined) {
                    await this.restClient.post(`${tenant.baseUrl}/StringParameters`, body, opContext, {
                        headers,
                    });
                }
                else {
                    await this.restClient.put(this.parameterUrl(tenant, parameter.pid, parameter.id), body, opContext, { headers });
                }
                // Read back so the caller sees the tenant's persisted value + audit fields, not our input.
                const persisted = await this.odataClient.getEntity(this.parameterUrl(tenant, parameter.pid, parameter.id), tenant, opContext);
                return persisted === undefined
                    ? {
                        pid: parameter.pid,
                        id: parameter.id,
                        value: parameter.value,
                        lastModifiedBy: undefined,
                        lastModifiedAt: undefined,
                    }
                    : RealPartnerDirectoryProvider.toDomain(persisted);
            },
        });
    }
    /** @inheritdoc */
    async deleteStringParameter(context, pid, id) {
        return this.pipeline.run({
            operationName: "partnerDirectory.deleteStringParameter",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const existing = await this.odataClient.getEntity(this.parameterUrl(tenant, pid, id), tenant, opContext);
                if (existing === undefined) {
                    return;
                }
                const csrf = await this.fetchCsrf(tenant, opContext);
                await this.restClient.delete(this.parameterUrl(tenant, pid, id), opContext, {
                    headers: RealPartnerDirectoryProvider.writeHeaders(tenant, csrf),
                });
            },
        });
    }
    /** @inheritdoc */
    async getBinaryParameter(context, pid, id) {
        return this.pipeline.run({
            operationName: "partnerDirectory.getBinaryParameter",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const raw = await this.odataClient.getEntity(this.binaryParameterUrl(tenant, pid, id), tenant, opContext);
                return raw === undefined ? undefined : RealPartnerDirectoryProvider.toBinaryDomain(raw);
            },
        });
    }
    /** @inheritdoc */
    async listBinaryParameters(context, pid) {
        return this.pipeline.run({
            operationName: "partnerDirectory.listBinaryParameters",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const items = await this.odataClient.queryAllPages(`${tenant.baseUrl}/BinaryParameters`, new ODataQueryBuilder().filter(ODataFilter.eq("Pid", pid)), tenant, opContext);
                return items.map(RealPartnerDirectoryProvider.toBinaryDomain);
            },
        });
    }
    /** @inheritdoc */
    async upsertBinaryParameter(context, parameter) {
        return this.pipeline.run({
            operationName: "partnerDirectory.upsertBinaryParameter",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const existing = await this.odataClient.getEntity(this.binaryParameterUrl(tenant, parameter.pid, parameter.id), tenant, opContext);
                const csrf = await this.fetchCsrf(tenant, opContext);
                const headers = RealPartnerDirectoryProvider.writeHeaders(tenant, csrf);
                const body = {
                    Pid: parameter.pid,
                    Id: parameter.id,
                    ContentType: parameter.contentType,
                    Value: parameter.valueBase64,
                };
                if (existing === undefined) {
                    await this.restClient.post(`${tenant.baseUrl}/BinaryParameters`, body, opContext, {
                        headers,
                    });
                }
                else {
                    await this.restClient.put(this.binaryParameterUrl(tenant, parameter.pid, parameter.id), body, opContext, { headers });
                }
                // Read back so the caller sees the tenant's persisted value + audit fields, not our input.
                const persisted = await this.odataClient.getEntity(this.binaryParameterUrl(tenant, parameter.pid, parameter.id), tenant, opContext);
                return persisted === undefined
                    ? {
                        pid: parameter.pid,
                        id: parameter.id,
                        contentType: parameter.contentType,
                        valueBase64: parameter.valueBase64,
                        lastModifiedBy: undefined,
                        lastModifiedAt: undefined,
                    }
                    : RealPartnerDirectoryProvider.toBinaryDomain(persisted);
            },
        });
    }
    /** @inheritdoc */
    async deleteBinaryParameter(context, pid, id) {
        return this.pipeline.run({
            operationName: "partnerDirectory.deleteBinaryParameter",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const existing = await this.odataClient.getEntity(this.binaryParameterUrl(tenant, pid, id), tenant, opContext);
                if (existing === undefined) {
                    return;
                }
                const csrf = await this.fetchCsrf(tenant, opContext);
                await this.restClient.delete(this.binaryParameterUrl(tenant, pid, id), opContext, {
                    headers: RealPartnerDirectoryProvider.writeHeaders(tenant, csrf),
                });
            },
        });
    }
    /**
     * Performs the CPI CSRF handshake: a GET on the service root with `X-CSRF-Token: Fetch`, reading
     * the issued token and any session cookie from the response headers (both keyed lower-case by the
     * HTTP layer). Best-effort — a tenant that doesn't require CSRF simply returns no token, and the
     * subsequent write proceeds without one.
     */
    async fetchCsrf(tenant, context) {
        const response = await this.httpClient.execute({
            method: "GET",
            url: `${tenant.baseUrl}/`,
            headers: { ...tenant.headers, Accept: "application/json", "X-CSRF-Token": "Fetch" },
        }, context);
        return {
            token: response.headers.get("x-csrf-token"),
            cookie: response.headers.get("set-cookie"),
        };
    }
    parameterUrl(tenant, pid, id) {
        return `${tenant.baseUrl}/StringParameters(Pid=${toODataV2KeyLiteral(pid)},Id=${toODataV2KeyLiteral(id)})`;
    }
    binaryParameterUrl(tenant, pid, id) {
        return `${tenant.baseUrl}/BinaryParameters(Pid=${toODataV2KeyLiteral(pid)},Id=${toODataV2KeyLiteral(id)})`;
    }
    static writeHeaders(tenant, csrf) {
        const headers = { ...tenant.headers, Accept: "application/json" };
        if (csrf.token !== undefined) {
            headers["X-CSRF-Token"] = csrf.token;
        }
        if (csrf.cookie !== undefined) {
            headers.Cookie = csrf.cookie;
        }
        return headers;
    }
    static toDomain(raw) {
        return {
            pid: raw.Pid,
            id: raw.Id,
            value: raw.Value,
            lastModifiedBy: raw.LastModifiedBy,
            lastModifiedAt: parseODataV2DateTime(raw.LastModifiedTime),
        };
    }
    static toBinaryDomain(raw) {
        return {
            pid: raw.Pid,
            id: raw.Id,
            contentType: raw.ContentType,
            valueBase64: raw.Value,
            lastModifiedBy: raw.LastModifiedBy,
            lastModifiedAt: parseODataV2DateTime(raw.LastModifiedTime),
        };
    }
}
//# sourceMappingURL=RealPartnerDirectoryProvider.js.map