/** Master CoE Partner ID whose global settings the mock is seeded with. */
const SYS_PID = ".SYS_JMS_FRAMEWORK";
/** Seed values so mock mode + unit tests have a realistic, writable `.SYS_JMS_FRAMEWORK`. */
const SEED = [
    {
        pid: SYS_PID,
        id: "Environment",
        value: "DEV",
        lastModifiedBy: "mock",
        lastModifiedAt: undefined,
    },
    {
        pid: SYS_PID,
        id: "DEFAULT_RETRIES",
        value: "5",
        lastModifiedBy: "mock",
        lastModifiedAt: undefined,
    },
    {
        pid: SYS_PID,
        id: "Default_Exception_To",
        value: "coe-support@middlewareops.com",
        lastModifiedBy: "mock",
        lastModifiedAt: undefined,
    },
    {
        pid: SYS_PID,
        id: "X-Default-Egress-URI",
        value: "/ProcessDirect/CatchAll",
        lastModifiedBy: "mock",
        lastModifiedAt: undefined,
    },
    // A pre-existing JMS agreement pointing at a different partner, so the Route Wizard's collision
    // check has a "ruleset" case to resolve against. Agreements are string parameters under the fixed
    // `_Maintain_JMS_Agreements` registry PID, keyed `.{SNDPRN}.{RCVPRN}`, valued with the target PID.
    {
        pid: "_Maintain_JMS_Agreements",
        id: ".SHOPIFY.S4HANA",
        value: "PID_EXISTING_OWNER",
        lastModifiedBy: "mock",
        lastModifiedAt: undefined,
    },
    // The Common Router analogue: a pre-existing router agreement pointing at a different Common Router
    // package, so the Common Router flow's collision check has a "ruleset" case to resolve against.
    {
        pid: "_Maintain_Router_Agreements",
        id: ".SHOPIFY.S4HANA",
        value: "Common_Router_Existing",
        lastModifiedBy: "mock",
        lastModifiedAt: undefined,
    },
];
/**
 * Mock implementation of {@link IPartnerDirectoryProvider} (architecture: Provider Framework, §10).
 * Unlike the read-only mock providers, this one is stateful: an in-memory store (per client
 * instance) seeded with the `.SYS_JMS_FRAMEWORK` global settings, so the create/update path is
 * genuinely exercisable in mock mode and unit tests without hitting a tenant.
 */
export class MockPartnerDirectoryProvider {
    store = new Map();
    binaryStore = new Map();
    constructor() {
        for (const parameter of SEED) {
            this.store.set(MockPartnerDirectoryProvider.key(parameter.pid, parameter.id), parameter);
        }
    }
    /** @inheritdoc */
    getStringParameter(_context, pid, id) {
        return Promise.resolve(this.store.get(MockPartnerDirectoryProvider.key(pid, id)));
    }
    /** @inheritdoc */
    listStringParameters(_context, pid) {
        const items = [...this.store.values()].filter((parameter) => parameter.pid === pid);
        return Promise.resolve(items);
    }
    /** @inheritdoc */
    upsertStringParameter(_context, parameter) {
        const persisted = {
            pid: parameter.pid,
            id: parameter.id,
            value: parameter.value,
            lastModifiedBy: "mock",
            lastModifiedAt: new Date().toISOString(),
        };
        this.store.set(MockPartnerDirectoryProvider.key(parameter.pid, parameter.id), persisted);
        return Promise.resolve(persisted);
    }
    /** @inheritdoc */
    deleteStringParameter(_context, pid, id) {
        this.store.delete(MockPartnerDirectoryProvider.key(pid, id));
        return Promise.resolve();
    }
    /** @inheritdoc */
    getBinaryParameter(_context, pid, id) {
        return Promise.resolve(this.binaryStore.get(MockPartnerDirectoryProvider.key(pid, id)));
    }
    /** @inheritdoc */
    listBinaryParameters(_context, pid) {
        const items = [...this.binaryStore.values()].filter((parameter) => parameter.pid === pid);
        return Promise.resolve(items);
    }
    /** @inheritdoc */
    upsertBinaryParameter(_context, parameter) {
        const persisted = {
            pid: parameter.pid,
            id: parameter.id,
            contentType: parameter.contentType,
            valueBase64: parameter.valueBase64,
            lastModifiedBy: "mock",
            lastModifiedAt: new Date().toISOString(),
        };
        this.binaryStore.set(MockPartnerDirectoryProvider.key(parameter.pid, parameter.id), persisted);
        return Promise.resolve(persisted);
    }
    /** @inheritdoc */
    deleteBinaryParameter(_context, pid, id) {
        this.binaryStore.delete(MockPartnerDirectoryProvider.key(pid, id));
        return Promise.resolve();
    }
    static key(pid, id) {
        return `${pid} ${id}`;
    }
}
//# sourceMappingURL=MockPartnerDirectoryProvider.js.map