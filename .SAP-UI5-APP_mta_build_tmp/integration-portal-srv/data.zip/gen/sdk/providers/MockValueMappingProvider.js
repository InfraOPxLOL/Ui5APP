import { generateValueMappingSchemes } from "../mock/fixtures/index.js";
/** Mock implementation of {@link IValueMappingProvider} (architecture: Provider Framework, §10). */
export class MockValueMappingProvider {
    mockEngine;
    constructor(mockEngine) {
        this.mockEngine = mockEngine;
    }
    /** @inheritdoc */
    async listSchemes(context) {
        return this.mockEngine.resolve({
            operationKey: "valueMapping.listSchemes",
            tenantId: context.tenantId,
            generateSuccess: () => generateValueMappingSchemes(4),
            generateEmpty: () => [],
        });
    }
    /** @inheritdoc */
    async getScheme(context, schemeName) {
        const all = await this.mockEngine.resolve({
            operationKey: "valueMapping.getScheme",
            tenantId: context.tenantId,
            generateSuccess: () => generateValueMappingSchemes(4),
        });
        return all.find((scheme) => scheme.name === schemeName);
    }
}
//# sourceMappingURL=MockValueMappingProvider.js.map