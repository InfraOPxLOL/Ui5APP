import { generateRuntimeArtifacts } from "../mock/fixtures/index.js";
/** Mock implementation of {@link IRuntimeProvider} (architecture: Provider Framework, §10). */
export class MockRuntimeProvider {
    mockEngine;
    constructor(mockEngine) {
        this.mockEngine = mockEngine;
    }
    /** @inheritdoc */
    async listArtifacts(context) {
        return this.mockEngine.resolve({
            operationKey: "runtime.listArtifacts",
            tenantId: context.tenantId,
            generateSuccess: () => generateRuntimeArtifacts(6),
            generateEmpty: () => [],
            generateLarge: () => generateRuntimeArtifacts(250),
        });
    }
    /** @inheritdoc */
    async getArtifact(context, artifactId) {
        const all = await this.mockEngine.resolve({
            operationKey: "runtime.getArtifact",
            tenantId: context.tenantId,
            generateSuccess: () => generateRuntimeArtifacts(6),
        });
        return all.find((artifact) => artifact.artifactId === artifactId) ?? all[0];
    }
    /** @inheritdoc */
    async restartArtifact(context, artifactId) {
        await this.mockEngine.resolve({
            operationKey: "runtime.restartArtifact",
            tenantId: context.tenantId,
            generateSuccess: () => ({ artifactId }),
        });
    }
}
//# sourceMappingURL=MockRuntimeProvider.js.map