import { UpstreamError } from "../../core/errors/UpstreamError.js";
import { ODataClient } from "../odata/ODataClient.js";
import { ODataQueryBuilder } from "../odata/ODataQueryBuilder.js";
import { SdkRestClient } from "../rest/SdkRestClient.js";
import { toODataV2KeyLiteral } from "./RealProviderSupport.js";
const DEFAULT_JMS_ENDPOINTS = {
    queueEntitySet: "Queues",
    messagingQueueEntitySet: "MessagingQueues",
    messageEntitySet: "MessagingMessages",
    retryFunctionImport: "RetryMessagingMessages",
    moveFunctionImport: "MoveMessagingMessages",
};
const DEFAULT_MOVE_PARAMETERS = {
    sourceQueue: "sourceQueue",
    targetQueue: "targetQueue",
    messageIds: "jmsMessageIds",
};
/**
 * Message listing does not support `$top`/`$skip` (silently ignored) — the server applies a fixed
 * row cap of {@link MIN_MESSAGE_PAGE_SIZE} overridable per request via `pageSize` in the range
 * 100–10,000. Offset paging is therefore emulated client-side: fetch `skip + top` rows (clamped
 * into the server's accepted range) and slice.
 */
const MIN_MESSAGE_PAGE_SIZE = 100;
const MAX_MESSAGE_PAGE_SIZE = 10_000;
/** Batch size for purge's list-then-delete loop. */
const PURGE_BATCH_SIZE = 1_000;
/** Safety cap so a queue receiving new messages faster than purge deletes them cannot loop forever. */
const MAX_PURGE_BATCHES = 100;
/**
 * Live implementation of {@link IJmsProvider} against the Cloud Integration JMS OData API
 * (`Queues` + `MessagingQueues`/`MessagingMessages` + `RetryMessagingMessages` — see
 * {@link JmsProviderEndpoints} for exactly which surface backs which operation, and why).
 *
 * Field-mapping honesty: `Queues` exposes no per-queue consumer count, so
 * {@link QueueRuntimeInfo.consumerCount} is reported as `undefined` (unknown), never fabricated;
 * `MessagingMessages` exposes no per-message size, so {@link QueuedMessage.sizeBytes} is likewise
 * `undefined`.
 */
export class RealJmsProvider {
    pipeline;
    endpoints;
    moveParameters;
    odataClient;
    restClient;
    constructor(pipeline, httpClient, endpoints = DEFAULT_JMS_ENDPOINTS, moveParameters = DEFAULT_MOVE_PARAMETERS) {
        this.pipeline = pipeline;
        this.endpoints = endpoints;
        this.moveParameters = moveParameters;
        this.odataClient = new ODataClient(httpClient, "v2");
        this.restClient = new SdkRestClient(httpClient);
    }
    /** @inheritdoc */
    async getQueueStates(context, queueNames) {
        return this.pipeline.run({
            operationName: "jms.getQueueStates",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const results = [];
                for (const queueName of queueNames) {
                    // The contract omits unknown queues: `getEntity` already maps a 404 to `undefined`; a 400
                    // is the tenant rejecting the configured name outright (only [A-Za-z0-9_]{1,80} is a
                    // legal queue name), which equally means the queue cannot exist there. Any other failure
                    // (auth, network, 5xx) still aborts the whole call.
                    let raw;
                    try {
                        raw = await this.odataClient.getEntity(`${tenant.baseUrl}/${this.endpoints.queueEntitySet}(${toODataV2KeyLiteral(queueName)})`, tenant, opContext);
                    }
                    catch (error) {
                        if (!RealJmsProvider.isQueueNameRejected(error)) {
                            throw error;
                        }
                    }
                    if (raw !== undefined) {
                        results.push(RealJmsProvider.toQueueDomain(raw));
                    }
                }
                return results;
            },
        });
    }
    /** @inheritdoc */
    async discoverQueues(context) {
        return this.pipeline.run({
            operationName: "jms.discoverQueues",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const all = await this.odataClient.queryAllPages(`${tenant.baseUrl}/${this.endpoints.queueEntitySet}`, new ODataQueryBuilder(), tenant, opContext);
                return all.map(RealJmsProvider.toQueueDomain);
            },
        });
    }
    /** @inheritdoc */
    async listMessages(context, queueName, page) {
        return this.pipeline.run({
            operationName: "jms.listMessages",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const pageSize = RealJmsProvider.clampPageSize(page.skip + page.top);
                const fetched = await this.fetchMessages(tenant, opContext, queueName, pageSize);
                const items = fetched
                    .slice(page.skip, page.skip + page.top)
                    .map(RealJmsProvider.toMessageDomain);
                // A short batch is authoritative for the total; a full batch means more rows exist beyond
                // the requested window, so read the queue's own live message count instead.
                const total = fetched.length < pageSize
                    ? fetched.length
                    : await this.fetchQueueMessageCount(tenant, opContext, queueName, fetched.length);
                return { items, total };
            },
        });
    }
    /** @inheritdoc */
    async deleteMessage(context, queueName, messageId) {
        return this.pipeline.run({
            operationName: "jms.deleteMessage",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                await this.restClient.delete(this.messageUrl(tenant, queueName, messageId), opContext, {
                    headers: RealJmsProvider.jsonHeaders(tenant),
                });
            },
        });
    }
    /** @inheritdoc */
    async purgeQueue(context, queueName) {
        return this.pipeline.run({
            operationName: "jms.purgeQueue",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                let removed = 0;
                for (let batch = 0; batch < MAX_PURGE_BATCHES; batch += 1) {
                    const messages = await this.fetchMessages(tenant, opContext, queueName, PURGE_BATCH_SIZE);
                    if (messages.length === 0) {
                        break;
                    }
                    for (const message of messages) {
                        await this.restClient.delete(this.messageUrl(tenant, queueName, message.jmsMessageId), opContext, { headers: RealJmsProvider.jsonHeaders(tenant) });
                        removed += 1;
                    }
                }
                return removed;
            },
        });
    }
    /** @inheritdoc */
    async retryMessage(context, queueName, messageId) {
        return this.pipeline.run({
            operationName: "jms.retryMessage",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                await this.restClient.post(`${tenant.baseUrl}/${this.endpoints.retryFunctionImport}`, { queueName, jmsMessageId: messageId }, opContext, { headers: RealJmsProvider.jsonHeaders(tenant) });
            },
        });
    }
    /** @inheritdoc */
    async moveMessages(context, sourceQueue, targetQueue, messageIds) {
        if (messageIds.length === 0) {
            return;
        }
        return this.pipeline.run({
            operationName: "jms.moveMessages",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                await this.restClient.post(`${tenant.baseUrl}/${this.endpoints.moveFunctionImport}`, {
                    [this.moveParameters.sourceQueue]: sourceQueue,
                    [this.moveParameters.targetQueue]: targetQueue,
                    [this.moveParameters.messageIds]: [...messageIds],
                }, opContext, { headers: RealJmsProvider.jsonHeaders(tenant) });
            },
        });
    }
    /** @inheritdoc */
    async getMessage(context, queueName, messageId) {
        return this.pipeline.run({
            operationName: "jms.getMessage",
            tenantId: context.tenantId,
            correlationId: context.correlationId,
            execute: async (tenant, opContext) => {
                const raw = await this.odataClient.getEntity(this.messageUrl(tenant, queueName, messageId), tenant, opContext);
                return raw === undefined ? undefined : RealJmsProvider.toMessageDomain(raw);
            },
        });
    }
    // --- Shared fetch helpers -------------------------------------------------
    /**
     * Lists one batch of a queue's messages via the only supported path,
     * `MessagingQueues('q')/MessagingMessages?pageSize=N` (OData system query options like `$filter`
     * are rejected with 400 on this surface; `pageSize` is its own, non-`$` parameter).
     */
    async fetchMessages(tenant, opContext, queueName, pageSize) {
        const url = `${tenant.baseUrl}/${this.endpoints.messagingQueueEntitySet}(${toODataV2KeyLiteral(queueName)})/${this.endpoints.messageEntitySet}`;
        const response = await this.restClient.get(url, opContext, {
            headers: RealJmsProvider.jsonHeaders(tenant),
            query: { pageSize: String(RealJmsProvider.clampPageSize(pageSize)) },
        });
        return response.data?.d?.results ?? [];
    }
    /** Reads a queue's live `numberOfMessages`; falls back to the fetched count if the queue read fails. */
    async fetchQueueMessageCount(tenant, opContext, queueName, fallback) {
        const raw = await this.odataClient.getEntity(`${tenant.baseUrl}/${this.endpoints.messagingQueueEntitySet}(${toODataV2KeyLiteral(queueName)})`, tenant, opContext);
        return raw === undefined ? fallback : RealJmsProvider.toCount(raw.numberOfMessages);
    }
    /** Builds the composite-key URL addressing one message (`jmsMessageId` + `queueName`). */
    messageUrl(tenant, queueName, messageId) {
        return `${tenant.baseUrl}/${this.endpoints.messageEntitySet}(jmsMessageId=${toODataV2KeyLiteral(messageId)},queueName=${toODataV2KeyLiteral(queueName)})`;
    }
    // --- Mapping ---------------------------------------------------------------
    static toQueueDomain(raw) {
        return {
            queueName: raw.Name,
            state: RealJmsProvider.toCount(raw.Active) === 1 ? "STARTED" : "STOPPED",
            messageCount: RealJmsProvider.toCount(raw.NumbOfMsgs),
            // `Queues` exposes no per-queue consumer count — unknown, never fabricated.
            consumerCount: undefined,
            capacityUsedPct: RealJmsProvider.toCount(raw.FillGrade),
        };
    }
    static toMessageDomain(raw) {
        return {
            messageId: raw.jmsMessageId,
            queueName: raw.queueName,
            enqueuedAt: RealJmsProvider.epochMsToIso(raw.createdAt) ?? "",
            retryCount: RealJmsProvider.toCount(raw.retryCount),
            // `MessagingMessages` exposes no size property — unknown, never fabricated.
            sizeBytes: undefined,
        };
    }
    /** Parses an OData v2 numeric value (`Edm.Int64` arrives as a JSON string) into a number, `0` when absent. */
    static toCount(value) {
        if (value === undefined) {
            return 0;
        }
        const parsed = typeof value === "number" ? value : Number.parseInt(value, 10);
        return Number.isNaN(parsed) ? 0 : parsed;
    }
    /** Converts an epoch-milliseconds value (Int64-as-string) to an ISO 8601 string. */
    static epochMsToIso(value) {
        if (value === undefined) {
            return undefined;
        }
        const epochMs = typeof value === "number" ? value : Number.parseInt(value, 10);
        return Number.isNaN(epochMs) ? undefined : new Date(epochMs).toISOString();
    }
    static clampPageSize(requested) {
        return Math.min(Math.max(requested, MIN_MESSAGE_PAGE_SIZE), MAX_MESSAGE_PAGE_SIZE);
    }
    /** Whether an error is the tenant's 400 rejecting a queue name it considers invalid. */
    static isQueueNameRejected(error) {
        return error instanceof UpstreamError && error.upstreamStatus === 400;
    }
    /**
     * Merges `Accept: application/json` onto the tenant's auth headers — without it this OData v2
     * surface answers in Atom/XML (same Olingo-stack behaviour `ODataClient.jsonHeaders` documents).
     */
    static jsonHeaders(tenant) {
        return { ...tenant.headers, Accept: "application/json" };
    }
}
//# sourceMappingURL=RealJmsProvider.js.map