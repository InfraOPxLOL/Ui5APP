import { generateCertificates } from "../mock/fixtures/index.js";
/** Mock implementation of {@link ICertificateProvider} (architecture: Provider Framework, §10). */
export class MockCertificateProvider {
    mockEngine;
    constructor(mockEngine) {
        this.mockEngine = mockEngine;
    }
    /** @inheritdoc */
    async listCertificates(context) {
        return this.mockEngine.resolve({
            operationKey: "certificate.listCertificates",
            tenantId: context.tenantId,
            generateSuccess: () => generateCertificates(20),
            generateEmpty: () => [],
            generateLarge: () => generateCertificates(250),
        });
    }
    /** @inheritdoc */
    async listExpiring(context, withinDays) {
        const all = await this.mockEngine.resolve({
            operationKey: "certificate.listExpiring",
            tenantId: context.tenantId,
            generateSuccess: () => generateCertificates(20),
            generateEmpty: () => [],
        });
        const horizon = Date.now() + withinDays * 86400000;
        return all
            .filter((certificate) => new Date(certificate.validTo).getTime() <= horizon)
            .sort((a, b) => new Date(a.validTo).getTime() - new Date(b.validTo).getTime());
    }
}
//# sourceMappingURL=MockCertificateProvider.js.map