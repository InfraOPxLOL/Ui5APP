/**
 * @param response a paged response.
 * @returns whether another page exists beyond this one.
 */
export function hasNextPage(response) {
    return response.skip + response.items.length < response.total;
}
//# sourceMappingURL=PagedResponse.js.map