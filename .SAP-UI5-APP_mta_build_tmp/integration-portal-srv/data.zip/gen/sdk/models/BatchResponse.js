/**
 * @param response a batch response.
 * @returns the number of operations that failed.
 */
export function countBatchFailures(response) {
    return response.results.filter((result) => !result.success).length;
}
//# sourceMappingURL=BatchResponse.js.map