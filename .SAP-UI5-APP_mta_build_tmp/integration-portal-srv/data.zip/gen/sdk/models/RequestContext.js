/**
 * Builds a {@link RequestContext}, generating a correlation id when the caller doesn't already
 * have one to propagate (e.g. from an inbound HTTP request).
 * @param tenantId the target tenant id.
 * @param options optional correlation id, actor and abort signal.
 * @returns a complete request context.
 */
export function createRequestContext(tenantId, options = {}) {
    return {
        tenantId,
        correlationId: options.correlationId ?? crypto.randomUUID(),
        actor: options.actor,
        signal: options.signal,
    };
}
//# sourceMappingURL=RequestContext.js.map