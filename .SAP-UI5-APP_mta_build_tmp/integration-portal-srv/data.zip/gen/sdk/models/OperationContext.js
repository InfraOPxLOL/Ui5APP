/**
 * Creates a fresh {@link OperationContext} for the start of a pipeline execution.
 * @param request the caller-supplied request context.
 * @param operationName logical operation name for logging/metrics.
 * @returns a new, unstarted operation context.
 */
export function createOperationContext(request, operationName) {
    return { request, operationName, attempt: 1, bag: {} };
}
//# sourceMappingURL=OperationContext.js.map