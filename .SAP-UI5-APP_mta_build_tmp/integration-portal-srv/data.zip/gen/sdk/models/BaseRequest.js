export {};
//# sourceMappingURL=BaseRequest.js.map