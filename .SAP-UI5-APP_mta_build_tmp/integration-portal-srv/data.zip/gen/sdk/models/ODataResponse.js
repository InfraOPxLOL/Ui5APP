export {};
//# sourceMappingURL=ODataResponse.js.map