export {};
//# sourceMappingURL=BaseResponse.js.map