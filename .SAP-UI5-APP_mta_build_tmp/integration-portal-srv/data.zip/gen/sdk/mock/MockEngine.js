import { TimeoutError } from "../errors/TimeoutError.js";
import { NetworkError } from "../errors/NetworkError.js";
import { IntegrationSuiteError } from "../../core/errors/IntegrationSuiteError.js";
import { getLogger } from "../../core/logging/logger.js";
/**
 * The SDK's mock engine (architecture: Mock Engine, §11).
 *
 * Every mock provider implementation (`sdk/providers/*`) routes its data through
 * {@link MockEngine.resolve} instead of returning fixtures directly, so scenario selection
 * (success/empty/slow/large/multi-page/timeout/error/failure) is centralized and consistent across
 * every domain — a caller can develop against slow, empty, or failing responses for *any* module by
 * changing configuration, with no code change in the provider.
 */
export class MockEngine {
    config;
    logger = getLogger("sdk.mock");
    constructor(config) {
        this.config = config;
    }
    /** @returns whether mock mode is enabled. */
    isEnabled() {
        return this.config.enabled;
    }
    /**
     * Resolves one mock operation per the configured scenario.
     * @param options the operation's data generators and identifying key.
     * @returns the generated result (after any configured delay).
     * @throws {TimeoutError | IntegrationSuiteError | NetworkError} for the `timeout`/`error`/`failure` scenarios.
     */
    async resolve(options) {
        const scenario = this.scenarioFor(options.operationKey);
        this.logger.debug({ operation: options.operationKey, tenantId: options.tenantId, scenario }, "sdk.mock.resolve");
        switch (scenario) {
            case "success":
                return options.generateSuccess();
            case "empty":
                return (options.generateEmpty ?? options.generateSuccess)();
            case "slow":
                await MockEngine.delay(this.config.slowDelayMs ?? 3000);
                return options.generateSuccess();
            case "largePayload":
            case "multiPage":
                return (options.generateLarge ?? options.generateSuccess)();
            case "timeout":
                throw new TimeoutError(this.config.slowDelayMs ?? 30000, `Mock scenario "timeout" simulated for operation "${options.operationKey}".`);
            case "error":
                throw IntegrationSuiteError.fromCpiResponse(options.tenantId, 500, {
                    message: `Mock scenario "error" simulated for operation "${options.operationKey}".`,
                });
            case "failure":
                throw new NetworkError(`Mock scenario "failure" simulated for operation "${options.operationKey}".`);
            default: {
                const exhaustive = scenario;
                throw new Error(`Unhandled mock scenario: ${String(exhaustive)}`);
            }
        }
    }
    scenarioFor(operationKey) {
        return this.config.scenarioOverrides?.[operationKey] ?? this.config.defaultScenario;
    }
    static delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}
//# sourceMappingURL=MockEngine.js.map