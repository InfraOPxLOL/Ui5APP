export {};
//# sourceMappingURL=MockTypes.js.map