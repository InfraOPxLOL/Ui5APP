import { HttpErrorTranslator } from "../errors/HttpErrorTranslator.js";
/**
 * The SDK's generic REST framework (architecture: REST Framework, §6).
 *
 * Sits directly on {@link IHttpClient} and adds what a plain REST call needs beyond raw transport:
 * automatic JSON serialization/deserialization (XML and plain text pass through as strings —
 * see `sdk/odata` for structured XML metadata parsing), multipart form submission, binary
 * downloads, and translation of any non-2xx response into the SDK's typed error taxonomy via
 * {@link HttpErrorTranslator} — callers never see a raw status code or parse an error body
 * themselves. Every REST-based sub-client and provider is built on an `SdkRestClient` instance;
 * OData-based ones additionally layer `sdk/odata` on top of the same instance.
 */
export class SdkRestClient {
    httpClient;
    constructor(httpClient) {
        this.httpClient = httpClient;
    }
    /** Performs a GET request expecting a JSON/text/XML body. */
    get(url, context, options) {
        return this.send("GET", url, context, options);
    }
    /** Performs a POST request with a JSON/text/XML body. */
    post(url, body, context, options) {
        return this.send("POST", url, context, options, body);
    }
    /** Performs a PUT request with a JSON/text/XML body. */
    put(url, body, context, options) {
        return this.send("PUT", url, context, options, body);
    }
    /** Performs a PATCH request with a JSON/text/XML body. */
    patch(url, body, context, options) {
        return this.send("PATCH", url, context, options, body);
    }
    /** Performs a DELETE request. */
    delete(url, context, options) {
        return this.send("DELETE", url, context, options);
    }
    /**
     * Submits a `multipart/form-data` request (e.g. uploading a certificate or payload attachment).
     * @param url the absolute request URL.
     * @param fields the multipart fields.
     * @param context the operation context.
     * @param options request options (content-type is ignored — the body is always multipart).
     * @returns the parsed response.
     */
    async postMultipart(url, fields, context, options) {
        const response = await this.httpClient.execute({
            method: "POST",
            url,
            headers: options?.headers,
            query: options?.query,
            body: { encoding: "multipart", value: fields },
            timeoutMs: options?.timeoutMs,
            retry: options?.retry,
            signal: options?.signal,
        }, context);
        if (!response.ok) {
            throw HttpErrorTranslator.translate(context.request.tenantId, this.toErrorResponse(response.status, response.bodyText));
        }
        return {
            data: SdkRestClient.parseJson(response.bodyText),
            correlationId: context.request.correlationId,
            durationMs: response.durationMs,
            mocked: false,
        };
    }
    /**
     * Downloads a binary resource (certificate content, payload attachment) as raw bytes.
     * @param url the absolute request URL.
     * @param context the operation context.
     * @param options request options.
     * @returns the response with `data` as a `Uint8Array`.
     */
    async getBinary(url, context, options) {
        const response = await this.httpClient.execute({
            method: "GET",
            url,
            headers: options?.headers,
            query: options?.query,
            binaryResponse: true,
            timeoutMs: options?.timeoutMs,
            retry: options?.retry,
            signal: options?.signal,
        }, context);
        if (!response.ok) {
            throw HttpErrorTranslator.translate(context.request.tenantId, this.toErrorResponse(response.status, undefined));
        }
        return {
            data: response.bodyBinary ?? new Uint8Array(0),
            correlationId: context.request.correlationId,
            durationMs: response.durationMs,
            mocked: false,
        };
    }
    async send(method, url, context, options, body) {
        const response = await this.httpClient.execute({
            method,
            url,
            headers: options?.headers,
            query: options?.query,
            body: SdkRestClient.encodeBody(body, options?.contentType ?? "json"),
            timeoutMs: options?.timeoutMs,
            retry: options?.retry,
            signal: options?.signal,
        }, context);
        if (!response.ok) {
            throw HttpErrorTranslator.translate(context.request.tenantId, this.toErrorResponse(response.status, response.bodyText));
        }
        return {
            data: SdkRestClient.decodeBody(response.bodyText, options?.contentType ?? "json"),
            correlationId: context.request.correlationId,
            durationMs: response.durationMs,
            mocked: false,
        };
    }
    toErrorResponse(status, bodyText) {
        const parsed = SdkRestClient.tryParseJson(bodyText);
        const message = parsed?.error?.message ??
            parsed?.message ??
            bodyText ??
            `Request failed with status ${status}.`;
        const upstreamCode = parsed?.error?.code ?? parsed?.code;
        return { httpStatus: status, message, upstreamCode, rawBody: parsed ?? bodyText };
    }
    static encodeBody(body, contentType) {
        if (body === undefined) {
            return undefined;
        }
        switch (contentType) {
            case "xml":
                return { encoding: "xml", value: body };
            case "text":
                return { encoding: "text", value: body };
            case "json":
            default:
                return { encoding: "json", value: body };
        }
    }
    static decodeBody(bodyText, contentType) {
        if (contentType === "xml" || contentType === "text") {
            return (bodyText ?? "");
        }
        return SdkRestClient.parseJson(bodyText);
    }
    static parseJson(bodyText) {
        if (bodyText === undefined || bodyText === "") {
            return undefined;
        }
        return JSON.parse(bodyText);
    }
    static tryParseJson(bodyText) {
        if (bodyText === undefined || bodyText === "") {
            return undefined;
        }
        try {
            return JSON.parse(bodyText);
        }
        catch {
            return undefined;
        }
    }
}
//# sourceMappingURL=SdkRestClient.js.map