export {};
//# sourceMappingURL=RestTypes.js.map