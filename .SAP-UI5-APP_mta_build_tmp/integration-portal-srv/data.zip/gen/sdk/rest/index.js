/** Barrel for the SDK's REST framework. */
export { SdkRestClient } from "./SdkRestClient.js";
//# sourceMappingURL=index.js.map