import { createOperationContext } from "../models/OperationContext.js";
import { createRequestContext } from "../models/RequestContext.js";
import { AppError } from "../../core/errors/AppError.js";
import { ServiceError } from "../../core/errors/ServiceError.js";
import { getLogger } from "../../core/logging/logger.js";
/**
 * The SDK's request pipeline — the single orchestration point every provider/sub-client method
 * runs through (architecture: Request Pipeline, §7).
 *
 * Before the transport call: validates input, resolves the tenant's destination (base URL + live
 * auth headers, via {@link IDestinationResolver}), and assembles the {@link OperationContext}
 * (correlation id, actor, attempt bookkeeping). After the call: guarantees every thrown value is a
 * typed {@link AppError} (wrapping anything else as a {@link ServiceError} — the caller-supplied
 * `execute` and the HTTP layer normally already throw typed errors; this is the pipeline's own
 * safety net), logs the operation's total duration (distinct from the *per-HTTP-call* metrics the
 * `sdk/http` interceptors record, since one operation may issue several HTTP calls — e.g. a
 * paginated fetch or an OData batch), and reads/writes the optional cache.
 */
export class RequestPipeline {
    destinationResolver;
    logger = getLogger("sdk.pipeline");
    constructor(destinationResolver) {
        this.destinationResolver = destinationResolver;
    }
    /**
     * Runs one operation through the pipeline.
     * @param options the operation's configuration and transport callback.
     * @returns the operation's result.
     * @throws {AppError} always a typed application error; unexpected throwables are wrapped.
     */
    async run(options) {
        const correlationId = options.correlationId ?? crypto.randomUUID();
        const startedAt = Date.now();
        if (options.validate !== undefined && options.input !== undefined) {
            options.validate(options.input);
        }
        if (options.cache !== undefined) {
            const cached = options.cache.read(options.cache.key);
            if (cached !== undefined) {
                this.logger.debug({ operation: options.operationName, correlationId, cacheKey: options.cache.key }, "sdk.pipeline.cacheHit");
                return cached;
            }
        }
        const tenant = await this.destinationResolver.resolve({
            tenantId: options.tenantId,
            correlationId,
        });
        const requestContext = createRequestContext(tenant.tenantId, {
            correlationId,
            actor: options.actor,
            signal: options.signal,
        });
        const operationContext = createOperationContext(requestContext, options.operationName);
        operationContext.tenant = tenant;
        operationContext.startedAt = startedAt;
        this.logger.debug({ operation: options.operationName, correlationId, tenantId: tenant.tenantId }, "sdk.pipeline.start");
        try {
            const result = await options.execute(tenant, operationContext);
            this.logger.info({
                operation: options.operationName,
                correlationId,
                tenantId: tenant.tenantId,
                durationMs: Date.now() - startedAt,
            }, "sdk.pipeline.complete");
            options.cache?.write(options.cache.key, result);
            return result;
        }
        catch (error) {
            this.logger.warn({
                operation: options.operationName,
                correlationId,
                tenantId: tenant.tenantId,
                durationMs: Date.now() - startedAt,
                err: error instanceof Error ? error.message : String(error),
            }, "sdk.pipeline.failed");
            throw RequestPipeline.ensureAppError(error);
        }
    }
    static ensureAppError(error) {
        if (error instanceof AppError) {
            return error;
        }
        const message = error instanceof Error ? error.message : String(error);
        return new ServiceError(message, undefined, error);
    }
}
//# sourceMappingURL=RequestPipeline.js.map