/**
 * A simple in-memory, TTL-based cache implementing the {@link CacheHooks} contract — the default
 * caching strategy a caller can hand to {@link RequestPipeline}.
 *
 * Distinct from `core/memo/requestMemo` (Phase 1): that de-duplicates *in-flight* identical calls
 * and discards state the instant they settle; this caches *completed* results for a fixed TTL, so
 * repeated calls within the TTL window skip the network entirely. Purely in-process — consistent
 * with the stateless-backend constraint; each instance manages its own cache.
 */
export class MemoryCacheProvider {
    ttlMs;
    entries = new Map();
    constructor(ttlMs) {
        this.ttlMs = ttlMs;
    }
    /**
     * Builds a {@link CacheHooks} bound to this cache under one key.
     * @param key the cache key for this call.
     * @returns cache hooks for {@link RequestPipeline}.
     */
    hooksFor(key) {
        return {
            key,
            read: (k) => this.read(k),
            write: (k, value) => this.write(k, value),
        };
    }
    read(key) {
        const entry = this.entries.get(key);
        if (entry === undefined || Date.now() >= entry.expiresAt) {
            return undefined;
        }
        return entry.value;
    }
    write(key, value) {
        this.entries.set(key, { value, expiresAt: Date.now() + this.ttlMs });
    }
    /** Clears every cached entry. */
    clear() {
        this.entries.clear();
    }
}
//# sourceMappingURL=CacheHooks.js.map