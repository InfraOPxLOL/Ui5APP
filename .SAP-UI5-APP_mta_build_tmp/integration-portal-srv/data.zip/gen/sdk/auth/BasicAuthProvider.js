/**
 * HTTP Basic authentication. Credentials are injected at construction (resolved by the Destination
 * framework from a BTP Destination at runtime) — never hardcoded or read from a config file.
 */
export class BasicAuthProvider {
    credentials;
    type = "basic";
    constructor(credentials) {
        this.credentials = credentials;
    }
    /** @inheritdoc */
    getAuthHeaders(_context) {
        const token = Buffer.from(`${this.credentials.username}:${this.credentials.password}`).toString("base64");
        return Promise.resolve({ Authorization: `Basic ${token}` });
    }
}
//# sourceMappingURL=BasicAuthProvider.js.map