import { TokenCache } from "./TokenCache.js";
import { createOperationContext } from "../models/OperationContext.js";
import { createRequestContext } from "../models/RequestContext.js";
import { HttpErrorTranslator } from "../errors/HttpErrorTranslator.js";
/**
 * OAuth 2.0 Client Credentials grant. Requests a bearer token from `config.tokenUrl`, caches it
 * for its lifetime (via {@link TokenCache}) and refreshes automatically once it is within the
 * cache's expiry skew of expiring — callers never see the token-fetch round trip on every call.
 *
 * Depends on {@link IHttpClient} (never `fetch` directly, per the HTTP Infrastructure mandate) so
 * the token fetch itself benefits from retry/timeout/logging like any other SDK call.
 */
export class OAuthClientCredentialsProvider {
    config;
    httpClient;
    cache;
    type = "oauth-client-credentials";
    cacheKey;
    constructor(config, httpClient, cache = new TokenCache()) {
        this.config = config;
        this.httpClient = httpClient;
        this.cache = cache;
        this.cacheKey = `${config.clientId}@${config.tokenUrl}`;
    }
    /** @inheritdoc */
    async getAuthHeaders(context) {
        const cached = this.cache.get(this.cacheKey);
        if (cached !== undefined) {
            return { Authorization: `Bearer ${cached.value}` };
        }
        const token = await this.fetchToken(context);
        return { Authorization: `Bearer ${token}` };
    }
    async fetchToken(context) {
        const body = new URLSearchParams({
            grant_type: "client_credentials",
            client_id: this.config.clientId,
            client_secret: this.config.clientSecret,
            ...(this.config.scope !== undefined ? { scope: this.config.scope } : {}),
        }).toString();
        const operationContext = createOperationContext(createRequestContext(context.tenantId, { correlationId: context.correlationId }), "auth.oauthClientCredentials.fetchToken");
        const response = await this.httpClient.execute({
            method: "POST",
            url: this.config.tokenUrl,
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: { encoding: "text", value: body },
        }, operationContext);
        if (!response.ok) {
            const errorResponse = {
                httpStatus: response.status,
                message: `OAuth token request failed with status ${response.status}.`,
                rawBody: response.bodyText,
            };
            throw HttpErrorTranslator.translate(context.tenantId, errorResponse);
        }
        const payload = JSON.parse(response.bodyText ?? "{}");
        this.cache.set(this.cacheKey, payload.access_token, payload.expires_in * 1000);
        return payload.access_token;
    }
}
//# sourceMappingURL=OAuthClientCredentialsProvider.js.map