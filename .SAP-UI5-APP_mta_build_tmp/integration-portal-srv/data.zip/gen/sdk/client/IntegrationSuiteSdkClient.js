import { MockEngine } from "../mock/MockEngine.js";
import { MockAlertProvider, MockCertificateProvider, MockJmsProvider, MockMonitoringProvider, MockPartnerDirectoryProvider, MockPayloadProvider, MockRuntimeProvider, MockSplunkProvider, MockValueMappingProvider, RealAlertProvider, RealCertificateProvider, RealJmsProvider, RealMonitoringProvider, RealPartnerDirectoryProvider, RealPayloadProvider, RealRuntimeProvider, RealValueMappingProvider, } from "../providers/index.js";
import { RequestPipeline } from "../pipeline/RequestPipeline.js";
import { ConfigurationError } from "../../core/errors/ConfigurationError.js";
import { MonitoringClient } from "./MonitoringClient.js";
import { RuntimeClient } from "./RuntimeClient.js";
import { JmsClient } from "./JmsClient.js";
import { PayloadClient } from "./PayloadClient.js";
import { SplunkClient } from "./SplunkClient.js";
import { PartnerDirectoryClient } from "./PartnerDirectoryClient.js";
import { CertificateClient } from "./CertificateClient.js";
import { ValueMappingClient } from "./ValueMappingClient.js";
import { SecurityMaterialClient } from "./SecurityMaterialClient.js";
import { ApiManagementClient } from "./ApiManagementClient.js";
import { AlertNotificationClient } from "./AlertNotificationClient.js";
import { DesignTimeClient } from "./DesignTimeClient.js";
/**
 * The SDK's root entry point (architecture: Integration Suite Client, §4).
 *
 * Composes and exposes one sub-client per Integration Suite capability area, wired to either the
 * mock-data providers (`sdk/providers/Mock*`) built in Phase 4 or the live, Integration-Suite-backed
 * providers (`sdk/providers/Real*`) built in Phase 5 — selected by `options.providerMode`, never by
 * a code change (architecture: Phase 5 — "The implementation should be selected automatically
 * through configuration"). Every sub-client's own public shape is unchanged either way: this
 * composition root is the *only* place that knows which concrete provider class backs a given
 * sub-client.
 *
 * This is the only class module code outside the SDK should ever construct or depend on; nothing
 * above it should import `sdk/http`, `sdk/providers`, etc. directly (architecture: "Every future
 * module must communicate ONLY through this SDK").
 */
export class IntegrationSuiteSdkClient {
    /** Message/Live Monitoring and Dashboard data. */
    monitoring;
    /** Deployed runtime artifact state. */
    runtime;
    /** JMS queue runtime state, message management and retry. */
    jms;
    /** Message payload/attachment access. */
    payload;
    /** Certificate/keystore access. */
    certificate;
    /** Value mapping scheme access. */
    valueMapping;
    /** Security materials (certificate/keystore subset today; see its own README note). */
    securityMaterial;
    /** API Management proxy listing and traffic summary. */
    apiManagement;
    /** Alert events (local sweeps and/or SAP Alert Notification Service). */
    alertNotification;
    /** Design-time integration application browsing. */
    designTime;
    /**
     * Splunk-backed payload fallback, for messages recording no MPL attachments on the tenant
     * itself. Wired to {@link MockSplunkProvider} unconditionally, regardless of `providerMode` —
     * unlike `apiManagement`/`designTime` (which stay mock because they have no Phase-3 provider
     * contract of their own), `splunk` *does* have a real contract (`ISplunkProvider`) but is
     * mock-only today because real Splunk search-API querying isn't reachable from this trial
     * tenant — an environmental constraint, not an architectural gap. A future `RealSplunkProvider`
     * would slot in here exactly like `RealPayloadProvider` did.
     */
    splunk;
    /**
     * Partner Directory read/write access (`StringParameters`) — the backing store for the CoE
     * Framework's configuration surfaces. Uses the real, live provider in `"real"` mode (the first
     * SDK surface performing tenant *writes* beyond JMS message actions) and a stateful seeded mock
     * otherwise.
     */
    partnerDirectory;
    mockEngine;
    providerMode;
    constructor(options) {
        this.mockEngine = new MockEngine(options.mockEngineConfig);
        this.providerMode = options.providerMode ?? "mock";
        const tenantId = options.defaultTenantId;
        if (this.providerMode === "real") {
            if (options.real === undefined) {
                throw new ConfigurationError('IntegrationSuiteSdkClient: providerMode "real" requires `real` dependencies (destinationResolver, httpClient).');
            }
            const { destinationResolver, httpClient } = options.real;
            const pipeline = new RequestPipeline(destinationResolver);
            this.monitoring = new MonitoringClient(new RealMonitoringProvider(pipeline, httpClient), tenantId);
            this.runtime = new RuntimeClient(new RealRuntimeProvider(pipeline, httpClient), tenantId);
            this.jms = new JmsClient(new RealJmsProvider(pipeline, httpClient, options.real.jmsEndpoints), tenantId);
            this.payload = new PayloadClient(new RealPayloadProvider(pipeline, httpClient), tenantId);
            const certificateProvider = new RealCertificateProvider(pipeline, httpClient);
            this.certificate = new CertificateClient(certificateProvider, tenantId);
            this.valueMapping = new ValueMappingClient(new RealValueMappingProvider(pipeline, httpClient, options.real.valueMappingEndpoints), tenantId);
            this.securityMaterial = new SecurityMaterialClient(certificateProvider, tenantId);
            this.apiManagement = new ApiManagementClient(this.mockEngine, tenantId);
            this.alertNotification = new AlertNotificationClient(options.real.alertNotification !== undefined
                ? new RealAlertProvider(httpClient, options.real.alertNotification)
                : new MockAlertProvider(this.mockEngine), tenantId);
            this.designTime = new DesignTimeClient(this.mockEngine, tenantId);
            this.splunk = new SplunkClient(new MockSplunkProvider(this.mockEngine), tenantId);
            this.partnerDirectory = new PartnerDirectoryClient(new RealPartnerDirectoryProvider(pipeline, httpClient), tenantId);
            return;
        }
        this.monitoring = new MonitoringClient(new MockMonitoringProvider(this.mockEngine), tenantId);
        this.runtime = new RuntimeClient(new MockRuntimeProvider(this.mockEngine), tenantId);
        this.jms = new JmsClient(new MockJmsProvider(this.mockEngine), tenantId);
        this.payload = new PayloadClient(new MockPayloadProvider(this.mockEngine), tenantId);
        const certificateProvider = new MockCertificateProvider(this.mockEngine);
        this.certificate = new CertificateClient(certificateProvider, tenantId);
        this.valueMapping = new ValueMappingClient(new MockValueMappingProvider(this.mockEngine), tenantId);
        this.securityMaterial = new SecurityMaterialClient(certificateProvider, tenantId);
        this.apiManagement = new ApiManagementClient(this.mockEngine, tenantId);
        this.alertNotification = new AlertNotificationClient(new MockAlertProvider(this.mockEngine), tenantId);
        this.designTime = new DesignTimeClient(this.mockEngine, tenantId);
        this.splunk = new SplunkClient(new MockSplunkProvider(this.mockEngine), tenantId);
        this.partnerDirectory = new PartnerDirectoryClient(new MockPartnerDirectoryProvider(), tenantId);
    }
    /** @returns whether the SDK is currently serving mock data (`providerMode !== "real"`). */
    isMockModeEnabled() {
        return this.providerMode === "mock";
    }
}
//# sourceMappingURL=IntegrationSuiteSdkClient.js.map