import { resolveContext } from "./ClientCallContext.js";
/**
 * JMS queue sub-client (architecture: Integration Suite Client, §4 — `JmsClient`). Wraps
 * {@link IJmsProvider} for queue runtime state, message management and message retry.
 * {@link JmsClient.retryMessage} is provider-backed: the Cloud Integration JMS OData API's
 * `RetryMessagingMessages` function import in real mode, the mock engine's `jms.retryMessage`
 * operation key in mock mode (see `RealJmsProvider`/`MockJmsProvider.retryMessage`).
 */
export class JmsClient {
    provider;
    defaultTenantId;
    constructor(provider, defaultTenantId) {
        this.provider = provider;
        this.defaultTenantId = defaultTenantId;
    }
    /** Reads runtime state for the given queues. See {@link IJmsProvider.getQueueStates}. */
    getQueueStates(queueNames, context) {
        return this.provider.getQueueStates(resolveContext(this.defaultTenantId, context), queueNames);
    }
    /** Discovers every queue the tenant reports, live. See {@link IJmsProvider.discoverQueues}. */
    discoverQueues(context) {
        return this.provider.discoverQueues(resolveContext(this.defaultTenantId, context));
    }
    /** Lists messages on a queue. See {@link IJmsProvider.listMessages}. */
    listMessages(queueName, page, context) {
        return this.provider.listMessages(resolveContext(this.defaultTenantId, context), queueName, page);
    }
    /** Deletes one message from a queue. See {@link IJmsProvider.deleteMessage}. */
    deleteMessage(queueName, messageId, context) {
        return this.provider.deleteMessage(resolveContext(this.defaultTenantId, context), queueName, messageId);
    }
    /** Purges all messages from a queue. See {@link IJmsProvider.purgeQueue}. */
    purgeQueue(queueName, context) {
        return this.provider.purgeQueue(resolveContext(this.defaultTenantId, context), queueName);
    }
    /**
     * Requests a retry of a queue-parked message. See {@link IJmsProvider.retryMessage}.
     * @param request the message (and the queue it sits on) to retry.
     * @param context optional tenant/correlation override.
     * @returns the retry outcome; provider failures propagate as SDK-typed errors.
     */
    async retryMessage(request, context) {
        if (request.queueName === undefined || request.queueName === "") {
            throw new Error("JmsClient.retryMessage requires a queueName — queue-originated retries are the only provider-backed retry path.");
        }
        const resolved = resolveContext(this.defaultTenantId, context);
        await this.provider.retryMessage(resolved, request.queueName, request.messageId);
        return {
            messageId: request.messageId,
            accepted: true,
            correlationId: resolved.correlationId,
        };
    }
    /**
     * Moves specific messages between queues. See {@link IJmsProvider.moveMessages}.
     *
     * Acceptance is **not** proof of arrival — callers performing dead-letter recovery must verify with
     * {@link getMessage} on the target queue before retrying.
     * @param sourceQueue the queue the messages currently sit on.
     * @param targetQueue the queue to move them to.
     * @param messageIds the specific message ids to move.
     * @param context optional tenant/correlation override.
     */
    moveMessages(sourceQueue, targetQueue, messageIds, context) {
        return this.provider.moveMessages(resolveContext(this.defaultTenantId, context), sourceQueue, targetQueue, messageIds);
    }
    /** Reads one message by its composite key. See {@link IJmsProvider.getMessage}. */
    getMessage(queueName, messageId, context) {
        return this.provider.getMessage(resolveContext(this.defaultTenantId, context), queueName, messageId);
    }
}
//# sourceMappingURL=JmsClient.js.map