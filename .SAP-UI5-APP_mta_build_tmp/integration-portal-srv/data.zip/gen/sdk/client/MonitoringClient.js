import { resolveContext } from "./ClientCallContext.js";
/**
 * Message-monitoring sub-client (architecture: Integration Suite Client, §4 — `MonitoringClient`).
 * A thin facade over {@link IMonitoringProvider}: the SDK's public surface for the Message
 * Monitoring, Live Monitoring and Dashboard modules. Holds no business logic itself — every method
 * delegates directly to the injected provider (mock today; a real CPI-backed provider in a future
 * phase, with zero change to this facade).
 */
export class MonitoringClient {
    provider;
    defaultTenantId;
    constructor(provider, defaultTenantId) {
        this.provider = provider;
        this.defaultTenantId = defaultTenantId;
    }
    /** Queries message processing logs. See {@link IMonitoringProvider.queryMessageLogs}. */
    queryMessageLogs(filter, page, context) {
        return this.provider.queryMessageLogs(resolveContext(this.defaultTenantId, context), filter, page);
    }
    /** Reads a single message processing log. See {@link IMonitoringProvider.getMessageLog}. */
    getMessageLog(messageId, context) {
        return this.provider.getMessageLog(resolveContext(this.defaultTenantId, context), messageId);
    }
    /** Reads a failed message's error details. See {@link IMonitoringProvider.getErrorDetails}. */
    getErrorDetails(messageId, context) {
        return this.provider.getErrorDetails(resolveContext(this.defaultTenantId, context), messageId);
    }
    /** Counts messages per status within a window. See {@link IMonitoringProvider.countByStatus}. */
    countByStatus(fromIso, toIso, context) {
        return this.provider.countByStatus(resolveContext(this.defaultTenantId, context), fromIso, toIso);
    }
    /** Reads a message's custom headers. See {@link IMonitoringProvider.getCustomHeaders}. */
    getCustomHeaders(messageId, context) {
        return this.provider.getCustomHeaders(resolveContext(this.defaultTenantId, context), messageId);
    }
}
//# sourceMappingURL=MonitoringClient.js.map