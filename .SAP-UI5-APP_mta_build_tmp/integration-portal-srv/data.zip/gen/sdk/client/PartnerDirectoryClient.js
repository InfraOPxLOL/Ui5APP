import { resolveContext } from "./ClientCallContext.js";
/**
 * Partner Directory sub-client (architecture: Integration Suite Client, §4). Thin facade over
 * {@link IPartnerDirectoryProvider} for the CoE Framework's configuration surfaces, mirroring
 * `PayloadClient`'s shape.
 */
export class PartnerDirectoryClient {
    provider;
    defaultTenantId;
    constructor(provider, defaultTenantId) {
        this.provider = provider;
        this.defaultTenantId = defaultTenantId;
    }
    /** Reads one string parameter. See {@link IPartnerDirectoryProvider.getStringParameter}. */
    getStringParameter(pid, id, context) {
        return this.provider.getStringParameter(resolveContext(this.defaultTenantId, context), pid, id);
    }
    /** Lists every string parameter under one Partner ID. See {@link IPartnerDirectoryProvider.listStringParameters}. */
    listStringParameters(pid, context) {
        return this.provider.listStringParameters(resolveContext(this.defaultTenantId, context), pid);
    }
    /** Creates or updates one string parameter. See {@link IPartnerDirectoryProvider.upsertStringParameter}. */
    upsertStringParameter(parameter, context) {
        return this.provider.upsertStringParameter(resolveContext(this.defaultTenantId, context), parameter);
    }
    /** Deletes one string parameter. See {@link IPartnerDirectoryProvider.deleteStringParameter}. */
    deleteStringParameter(pid, id, context) {
        return this.provider.deleteStringParameter(resolveContext(this.defaultTenantId, context), pid, id);
    }
    /** Reads one binary parameter. See {@link IPartnerDirectoryProvider.getBinaryParameter}. */
    getBinaryParameter(pid, id, context) {
        return this.provider.getBinaryParameter(resolveContext(this.defaultTenantId, context), pid, id);
    }
    /** Lists every binary parameter under one Partner ID. See {@link IPartnerDirectoryProvider.listBinaryParameters}. */
    listBinaryParameters(pid, context) {
        return this.provider.listBinaryParameters(resolveContext(this.defaultTenantId, context), pid);
    }
    /** Creates or updates one binary parameter. See {@link IPartnerDirectoryProvider.upsertBinaryParameter}. */
    upsertBinaryParameter(parameter, context) {
        return this.provider.upsertBinaryParameter(resolveContext(this.defaultTenantId, context), parameter);
    }
    /** Deletes one binary parameter. See {@link IPartnerDirectoryProvider.deleteBinaryParameter}. */
    deleteBinaryParameter(pid, id, context) {
        return this.provider.deleteBinaryParameter(resolveContext(this.defaultTenantId, context), pid, id);
    }
}
//# sourceMappingURL=PartnerDirectoryClient.js.map