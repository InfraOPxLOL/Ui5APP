import { resolveContext } from "./ClientCallContext.js";
/**
 * Splunk payload-fallback sub-client (architecture: Payload fallback). Thin facade over
 * {@link ISplunkProvider} for `PayloadEngine.prepareFromSplunk`, mirroring `PayloadClient`'s shape.
 */
export class SplunkClient {
    provider;
    defaultTenantId;
    constructor(provider, defaultTenantId) {
        this.provider = provider;
        this.defaultTenantId = defaultTenantId;
    }
    /** Looks up the Splunk-recorded event for one message. See {@link ISplunkProvider.getMessageEvent}. */
    getMessageEvent(messageId, hint, context) {
        return this.provider.getMessageEvent(resolveContext(this.defaultTenantId, context), messageId, hint);
    }
}
//# sourceMappingURL=SplunkClient.js.map