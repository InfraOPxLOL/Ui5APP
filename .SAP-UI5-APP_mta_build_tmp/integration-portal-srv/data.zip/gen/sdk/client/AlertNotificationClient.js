import { resolveContext } from "./ClientCallContext.js";
/**
 * Alert notification sub-client (architecture: Integration Suite Client, §4 —
 * `AlertNotificationClient`). Thin facade over {@link IAlertProvider} — whose contract already
 * covers alerts "raised locally or relayed from SAP Alert Notification Service" (Phase 3) — for the
 * Alert Center module and the shell's notification bell.
 */
export class AlertNotificationClient {
    provider;
    defaultTenantId;
    constructor(provider, defaultTenantId) {
        this.provider = provider;
        this.defaultTenantId = defaultTenantId;
    }
    /** Queries alert events, newest first. See {@link IAlertProvider.queryAlerts}. */
    queryAlerts(page, severity, context) {
        return this.provider.queryAlerts(resolveContext(this.defaultTenantId, context), page, severity);
    }
    /** Reads a single alert by id. See {@link IAlertProvider.getAlert}. */
    getAlert(alertId, context) {
        return this.provider.getAlert(resolveContext(this.defaultTenantId, context), alertId);
    }
}
//# sourceMappingURL=AlertNotificationClient.js.map