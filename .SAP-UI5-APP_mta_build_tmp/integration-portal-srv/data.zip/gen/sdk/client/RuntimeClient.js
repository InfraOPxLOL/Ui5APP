import { resolveContext } from "./ClientCallContext.js";
/**
 * Runtime-artifact sub-client (architecture: Integration Suite Client, §4 — `RuntimeClient`). Thin
 * facade over {@link IRuntimeProvider} for Live Monitoring's artifact health view and the
 * Dashboard's runtime KPIs.
 */
export class RuntimeClient {
    provider;
    defaultTenantId;
    constructor(provider, defaultTenantId) {
        this.provider = provider;
        this.defaultTenantId = defaultTenantId;
    }
    /** Lists deployed runtime artifacts. See {@link IRuntimeProvider.listArtifacts}. */
    listArtifacts(context) {
        return this.provider.listArtifacts(resolveContext(this.defaultTenantId, context));
    }
    /** Reads one artifact's runtime status. See {@link IRuntimeProvider.getArtifact}. */
    getArtifact(artifactId, context) {
        return this.provider.getArtifact(resolveContext(this.defaultTenantId, context), artifactId);
    }
    /** Requests a restart of a deployed artifact. See {@link IRuntimeProvider.restartArtifact}. */
    restartArtifact(artifactId, context) {
        return this.provider.restartArtifact(resolveContext(this.defaultTenantId, context), artifactId);
    }
}
//# sourceMappingURL=RuntimeClient.js.map