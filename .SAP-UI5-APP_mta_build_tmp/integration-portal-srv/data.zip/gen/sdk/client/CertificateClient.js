import { resolveContext } from "./ClientCallContext.js";
/**
 * Certificate sub-client (architecture: Integration Suite Client, §4 — `CertificateClient`). Thin
 * facade over {@link ICertificateProvider} for the Certificate Management module and its expiry
 * sweep.
 */
export class CertificateClient {
    provider;
    defaultTenantId;
    constructor(provider, defaultTenantId) {
        this.provider = provider;
        this.defaultTenantId = defaultTenantId;
    }
    /** Lists all keystore entries. See {@link ICertificateProvider.listCertificates}. */
    listCertificates(context) {
        return this.provider.listCertificates(resolveContext(this.defaultTenantId, context));
    }
    /** Lists entries expiring within a horizon. See {@link ICertificateProvider.listExpiring}. */
    listExpiring(withinDays, context) {
        return this.provider.listExpiring(resolveContext(this.defaultTenantId, context), withinDays);
    }
}
//# sourceMappingURL=CertificateClient.js.map