import { resolveContext } from "./ClientCallContext.js";
/**
 * Payload sub-client (architecture: Integration Suite Client, §4 — `PayloadClient`). Thin facade
 * over {@link IPayloadProvider} for the future Payload Viewer/Archive modules.
 */
export class PayloadClient {
    provider;
    defaultTenantId;
    constructor(provider, defaultTenantId) {
        this.provider = provider;
        this.defaultTenantId = defaultTenantId;
    }
    /** Lists attachment metadata for a message. See {@link IPayloadProvider.listAttachments}. */
    listAttachments(messageId, context) {
        return this.provider.listAttachments(resolveContext(this.defaultTenantId, context), messageId);
    }
    /** Reads one attachment including content. See {@link IPayloadProvider.getAttachment}. */
    getAttachment(messageId, attachmentId, context) {
        return this.provider.getAttachment(resolveContext(this.defaultTenantId, context), messageId, attachmentId);
    }
}
//# sourceMappingURL=PayloadClient.js.map