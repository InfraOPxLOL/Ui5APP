import { resolveContext } from "./ClientCallContext.js";
/**
 * Value mapping sub-client (architecture: Integration Suite Client, §4 — `ValueMappingClient`).
 * Thin facade over {@link IValueMappingProvider} for the Value Mapping module.
 */
export class ValueMappingClient {
    provider;
    defaultTenantId;
    constructor(provider, defaultTenantId) {
        this.provider = provider;
        this.defaultTenantId = defaultTenantId;
    }
    /** Lists all value mapping schemes. See {@link IValueMappingProvider.listSchemes}. */
    listSchemes(context) {
        return this.provider.listSchemes(resolveContext(this.defaultTenantId, context));
    }
    /** Reads a single scheme by name. See {@link IValueMappingProvider.getScheme}. */
    getScheme(schemeName, context) {
        return this.provider.getScheme(resolveContext(this.defaultTenantId, context), schemeName);
    }
}
//# sourceMappingURL=ValueMappingClient.js.map