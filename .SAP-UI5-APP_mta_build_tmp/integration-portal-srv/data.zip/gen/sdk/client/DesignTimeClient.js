import { generateApplications } from "../mock/fixtures/index.js";
import { resolveContext } from "./ClientCallContext.js";
/**
 * Design-time sub-client (architecture: Integration Suite Client, §4 — `DesignTimeClient`). No
 * Phase-3 provider contract exists for design-time content browsing, so this client generates its
 * {@link ApplicationDto} data directly through the {@link MockEngine} — backs the future
 * Integration Advisor / design-time browsing surfaces.
 */
export class DesignTimeClient {
    mockEngine;
    defaultTenantId;
    constructor(mockEngine, defaultTenantId) {
        this.mockEngine = mockEngine;
        this.defaultTenantId = defaultTenantId;
    }
    /**
     * Lists design-time integration applications (integration flows and other artifacts within
     * Integration Packages).
     * @param context optional tenant/correlation override.
     * @returns the application descriptors.
     */
    listApplications(context) {
        const resolved = resolveContext(this.defaultTenantId, context);
        return this.mockEngine.resolve({
            operationKey: "designTime.listApplications",
            tenantId: resolved.tenantId,
            generateSuccess: () => generateApplications(10),
            generateEmpty: () => [],
            generateLarge: () => generateApplications(250),
        });
    }
}
//# sourceMappingURL=DesignTimeClient.js.map