export {};
//# sourceMappingURL=PartnerDirectoryDto.js.map