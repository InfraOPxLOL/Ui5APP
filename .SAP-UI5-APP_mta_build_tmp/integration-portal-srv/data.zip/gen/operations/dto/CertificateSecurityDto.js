export {};
//# sourceMappingURL=CertificateSecurityDto.js.map