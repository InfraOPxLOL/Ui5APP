export {};
//# sourceMappingURL=HeaderDto.js.map