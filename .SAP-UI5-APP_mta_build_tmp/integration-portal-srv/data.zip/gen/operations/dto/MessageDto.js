export {};
//# sourceMappingURL=MessageDto.js.map