export {};
//# sourceMappingURL=CertificateDto.js.map