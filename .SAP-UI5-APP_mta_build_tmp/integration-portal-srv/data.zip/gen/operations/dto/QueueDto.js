export {};
//# sourceMappingURL=QueueDto.js.map