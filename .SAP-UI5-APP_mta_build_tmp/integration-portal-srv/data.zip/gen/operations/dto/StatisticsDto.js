export {};
//# sourceMappingURL=StatisticsDto.js.map