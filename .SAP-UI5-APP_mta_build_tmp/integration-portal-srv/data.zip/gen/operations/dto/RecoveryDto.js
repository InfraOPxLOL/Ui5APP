/**
 * Business-friendly DTOs for the Recovery Center (architecture: Phase 11, Recovery Engine). Built
 * entirely from `QueueEngine`/`JmsClient`/`RuntimeEngine` plus `config/queues.json`'s existing
 * `deadLetterQueue`/`retryQueue` pairing — no new configuration concept, no SDK/CPI shape ever
 * crosses this boundary.
 */
export {};
//# sourceMappingURL=RecoveryDto.js.map