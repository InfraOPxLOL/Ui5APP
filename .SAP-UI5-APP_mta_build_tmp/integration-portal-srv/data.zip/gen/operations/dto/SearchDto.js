export {};
//# sourceMappingURL=SearchDto.js.map