/**
 * Business-friendly DTOs for processing-framework detection and framework-aware recovery (Phase 13).
 *
 * Two **independent** axes run through this file, and they are deliberately never merged into one
 * enum:
 *
 * - {@link ProcessingFramework} answers *"which processing framework owns this message?"* — an
 *   identity, derived from `config/frameworks.json`'s detection rules.
 * - {@link RecoveryState} answers *"what condition is this message in right now?"* — an operational
 *   state, derived from the message's own status plus (for the authoritative value) real queue
 *   probes.
 *
 * A failed TPM V2 message is `framework: "TPM_V2"` **and** `recoveryState: "DLQ_RECOVERY_AVAILABLE"`;
 * it is never a single fused "TPM_FAILURE" value, because failure state is not a framework and the
 * two filter independently.
 *
 * Nothing here is persisted — every value is recomputed per request from live MPL/queue data.
 */
export {};
//# sourceMappingURL=FrameworkDto.js.map