export {};
//# sourceMappingURL=AttachmentDto.js.map