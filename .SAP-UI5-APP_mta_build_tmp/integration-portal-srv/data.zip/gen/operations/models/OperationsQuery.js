/** The query every engine method receives when a caller passes none. */
export const DEFAULT_OPERATIONS_QUERY = {
    page: 1,
    pageSize: 50,
    sortDirection: "desc",
    includePayload: false,
    includeAttachments: false,
    includeHeaders: false,
};
export class OperationsQueryBuilder {
    state = {};
    status(value) {
        this.state.status = value;
        return this;
    }
    sender(value) {
        this.state.sender = value;
        return this;
    }
    receiver(value) {
        this.state.receiver = value;
        return this;
    }
    messageType(value) {
        this.state.messageType = value;
        return this;
    }
    customStatus(value) {
        this.state.customStatus = value;
        return this;
    }
    applicationId(value) {
        this.state.applicationId = value;
        return this;
    }
    integrationFlow(value) {
        this.state.integrationFlow = value;
        return this;
    }
    search(value) {
        this.state.search = value;
        return this;
    }
    dateFrom(iso) {
        this.state.dateFrom = iso;
        return this;
    }
    dateTo(iso) {
        this.state.dateTo = iso;
        return this;
    }
    durationRange(minMs, maxMs) {
        this.state.durationMinMs = minMs;
        this.state.durationMaxMs = maxMs;
        return this;
    }
    queue(value) {
        this.state.queue = value;
        return this;
    }
    certificate(value) {
        this.state.certificate = value;
        return this;
    }
    runtimeStatus(value) {
        this.state.runtimeStatus = value;
        return this;
    }
    page(value) {
        this.state.page = value;
        return this;
    }
    pageSize(value) {
        this.state.pageSize = value;
        return this;
    }
    sortBy(field) {
        this.state.sortBy = field;
        return this;
    }
    asc() {
        this.state.sortDirection = "asc";
        return this;
    }
    desc() {
        this.state.sortDirection = "desc";
        return this;
    }
    select(...fields) {
        this.state.select = fields;
        return this;
    }
    includePayload(value = true) {
        this.state.includePayload = value;
        return this;
    }
    includeAttachments(value = true) {
        this.state.includeAttachments = value;
        return this;
    }
    includeHeaders(value = true) {
        this.state.includeHeaders = value;
        return this;
    }
    /** @returns the assembled, immutable {@link OperationsQuery}. */
    build() {
        return { ...DEFAULT_OPERATIONS_QUERY, ...this.state };
    }
}
/**
 * Translates an {@link OperationsQuery}'s 1-based paging into the SDK's 0-based {@link ProviderPage}.
 * @param query the operations query.
 * @returns the equivalent `skip`/`top` pair.
 */
export function toProviderPage(query) {
    const pageSize = Math.max(1, query.pageSize);
    const page = Math.max(1, query.page);
    return { skip: (page - 1) * pageSize, top: pageSize };
}
//# sourceMappingURL=OperationsQuery.js.map