/**
 * The universal search facade (architecture: Phase 6, Search Engine, §3). Composes the domain
 * engines that already know how to fetch and filter their own data — `SearchEngine` adds no fetching
 * logic of its own, only the cross-domain entry points a search box needs (search by field-rich
 * query for messages; by id for exact lookups; by substring for queues/certificates). Every method
 * returns Operations DTOs only — no SDK object ever escapes through here.
 */
export class SearchEngine {
    messageEngine;
    queueEngine;
    certificateEngine;
    constructor(messageEngine, queueEngine, certificateEngine) {
        this.messageEngine = messageEngine;
        this.queueEngine = queueEngine;
        this.certificateEngine = certificateEngine;
    }
    /** Searches messages by the full field-rich {@link OperationsQuery} (status, sender, receiver, message type, custom status, application id, integration flow, date range, duration, free-text). */
    async searchMessages(query) {
        return this.messageEngine.queryMessages(query);
    }
    /** Finds one message by its exact id (also its MPL id — the two are the same value in this domain). */
    async findMessageById(messageId) {
        return this.messageEngine.getMessage(messageId);
    }
    /** Finds every message sharing a correlation id. */
    async findMessagesByCorrelationId(correlationId) {
        return this.messageEngine.findByCorrelationId(correlationId);
    }
    /** Searches queues by name/display-name substring (case-insensitive). */
    async searchQueues(term) {
        const needle = term.toLowerCase();
        const queues = await this.queueEngine.listQueues();
        return queues.filter((queue) => queue.queueName.toLowerCase().includes(needle) ||
            queue.displayName.toLowerCase().includes(needle));
    }
    /** Searches certificates by alias substring (case-insensitive). */
    async searchCertificates(term) {
        return this.certificateEngine.search({ alias: term });
    }
}
//# sourceMappingURL=SearchEngine.js.map