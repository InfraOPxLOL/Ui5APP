import { countByValue, humanReadableStatus, runtimeHealth } from "../transform/index.js";
/**
 * Aggregates deployed runtime artifact information (architecture: Phase 6, Runtime Engine, §6). The
 * only place any future module reads runtime artifact state from — always through
 * {@link RuntimeSummary}, never through `sdk.runtime`'s `RuntimeArtifactStatus` directly.
 */
export class RuntimeEngine {
    client;
    cache;
    constructor(client, cache) {
        this.client = client;
        this.cache = cache;
    }
    /** Lists every deployed runtime artifact, enriched with health/human-readable status. */
    async listArtifacts() {
        return this.cache.dedupe("runtime.list", async () => {
            const artifacts = await this.client.listArtifacts();
            return artifacts.map(RuntimeEngine.toSummary);
        });
    }
    /**
     * Reads one artifact's runtime status.
     * @param artifactId the runtime artifact id.
     * @returns the artifact summary, or `undefined` when not deployed.
     */
    async getArtifact(artifactId) {
        return this.cache.dedupe(`runtime.get:${artifactId}`, async () => {
            const artifact = await this.client.getArtifact(artifactId);
            return artifact === undefined ? undefined : RuntimeEngine.toSummary(artifact);
        });
    }
    /**
     * Requests a restart (redeploy) of a deployed artifact — a future runtime operation this engine
     * already exposes a stable seam for (architecture: Phase 6 — "Support future runtime operations").
     * @param artifactId the runtime artifact id.
     */
    async restartArtifact(artifactId) {
        return this.client.restartArtifact(artifactId);
    }
    /** @returns the distribution of artifacts across their raw status values. */
    async getStatusDistribution() {
        const artifacts = await this.listArtifacts();
        return countByValue(artifacts, (artifact) => artifact.status);
    }
    static toSummary(artifact) {
        return {
            artifactId: artifact.artifactId,
            name: artifact.name,
            type: artifact.type,
            version: artifact.version,
            status: artifact.status,
            humanReadableStatus: humanReadableStatus(artifact.status),
            health: runtimeHealth(artifact.status),
            deployedOn: artifact.deployedOn,
            deployedBy: artifact.deployedBy,
            errorText: artifact.errorText,
        };
    }
}
//# sourceMappingURL=RuntimeEngine.js.map