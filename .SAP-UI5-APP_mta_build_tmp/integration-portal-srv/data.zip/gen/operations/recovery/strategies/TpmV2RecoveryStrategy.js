import { QueueRecoveryStrategyBase } from "../QueueRecoveryStrategyBase.js";
/**
 * TPM V2 recovery (Phase 13, §3) — SAP's own Trading Partner Management framework.
 *
 * Locating a message is a deterministic walk down the configured `traversalOrder`, stopping at the
 * first queue that actually holds it:
 *
 * ```
 * SAP_TPM_INBOUND_Q
 *   ↓ not found
 * SAP_TPM_OUTBOUND_Q
 *   ↓ not found
 * SAP_TPM_COM_PROCESSING_OUTBOUND_DEAD_LETTER_Q
 *   ↓ not found
 * SAP_TPM_COM_RECEIVER_OUTOUND_DEAD_LETTER_Q
 *   ↓ not found
 * Manual investigation
 * ```
 *
 * The two dead-letter queues recover to *different* targets — processing → inbound, receiver →
 * outbound — which is exactly what `topology.dlqRecoveryMap` encodes, so the base class's generic
 * move → verify → retry needs no TPM-specific code. A message found on either active queue is
 * validated and retried in place.
 *
 * Every queue name comes from `config/frameworks.json`; none is hardcoded here, so a tenant whose
 * TPM queues are named differently is a configuration edit.
 */
export class TpmV2RecoveryStrategy extends QueueRecoveryStrategyBase {
    framework = "TPM_V2";
    constructor(config) {
        super(config);
    }
    /** @inheritdoc */
    async locate(context) {
        return this.traverse(context);
    }
}
//# sourceMappingURL=TpmV2RecoveryStrategy.js.map