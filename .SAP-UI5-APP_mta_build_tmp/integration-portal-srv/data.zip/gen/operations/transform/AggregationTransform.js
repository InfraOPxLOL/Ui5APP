/**
 * Generic counting/ranking helpers shared by `RuntimeEngine` (status distribution) and
 * `StatisticsEngine` (status/top-N distributions) — one implementation of "group by a derived key
 * and count" rather than a hand-rolled `reduce` per engine.
 */
/**
 * Groups `items` by a derived string key and counts each group.
 * @param items the items to group.
 * @param keyFn derives the grouping key for one item.
 * @returns one {@link CountEntry} per distinct key, in first-seen order.
 */
export function countByValue(items, keyFn) {
    const counts = new Map();
    for (const item of items) {
        const key = keyFn(item);
        counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return Array.from(counts.entries(), ([value, count]) => ({ value, count }));
}
/**
 * Groups `items` by a derived string key, counts each group, and returns the top `limit` by count.
 * @param items the items to group.
 * @param keyFn derives the grouping key for one item.
 * @param limit maximum number of entries to return.
 * @returns the top entries, highest count first.
 */
export function topRanked(items, keyFn, limit) {
    const counts = new Map();
    for (const item of items) {
        const key = keyFn(item);
        counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return Array.from(counts.entries(), ([key, count]) => ({ key, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, limit);
}
//# sourceMappingURL=AggregationTransform.js.map