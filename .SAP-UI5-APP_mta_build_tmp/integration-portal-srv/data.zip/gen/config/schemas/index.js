/**
 * Barrel for the per-domain configuration schemas. Each module pairs a zod schema (the runtime
 * validator) with its inferred TypeScript type (the compile-time contract), so the JSON files in
 * `config/` are strongly typed end to end. The zod schemas are the single source of truth for
 * what valid configuration looks like.
 *
 * (Backend-only barrel: the frontend toolchain's re-export limitation — convention 4d in
 * docs/SCAFFOLD_PROGRESS.md — does not apply to the NodeNext backend.)
 */
export { applicationSchema } from "./application.schema.js";
export { environmentSchema, ENVIRONMENT_KINDS, } from "./environment.schema.js";
export { tenantsSchema, tenantSchema, } from "./tenants.schema.js";
export { queuesSchema, queueSchema, RETRY_STRATEGIES, } from "./queues.schema.js";
export { frameworksSchema, frameworkSchema, frameworkDetectionSchema, frameworkTopologySchema, frameworkQueueResolutionSchema, headerMatchSchema, CONFIGURABLE_FRAMEWORK_IDS, } from "./frameworks.schema.js";
export { refreshSchema, refreshProfileSchema, } from "./refresh.schema.js";
export { featuresSchema, moduleToggleSchema, } from "./features.schema.js";
export { themeSchema, COMPACT_MODES } from "./theme.schema.js";
export { monitoringSchema } from "./monitoring.schema.js";
export { loggingSchema, LOG_LEVELS, } from "./logging.schema.js";
export { securitySchema } from "./security.schema.js";
export { connectivitySchema, tenantAuthSchema, CONNECTIVITY_MODES, DESTINATION_DISCOVERY_MODES, TENANT_AUTH_TYPES, } from "./connectivity.schema.js";
//# sourceMappingURL=index.js.map