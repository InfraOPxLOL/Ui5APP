/**
 * Typed, validated process environment loader.
 *
 * This is the only place `process.env` is read directly. It validates on first import and throws
 * immediately if a required variable is missing or malformed, so the app fails fast at boot rather
 * than on the first request (architecture §11).
 */
function parsePort(value) {
    const port = Number.parseInt(value ?? "4004", 10);
    if (Number.isNaN(port) || port <= 0) {
        throw new Error(`Invalid PORT value: "${value ?? ""}"`);
    }
    return port;
}
function parseNodeEnv(value) {
    const v = value ?? "development";
    if (v !== "development" && v !== "production" && v !== "test") {
        throw new Error(`Invalid NODE_ENV value: "${v}"`);
    }
    return v;
}
function parseQueueDiscoveryMode(value) {
    const v = value ?? "Fetch_Specific";
    if (v !== "Fetch_All" && v !== "Fetch_Specific") {
        throw new Error(`Invalid JMS_QUEUE_DISCOVERY_MODE value: "${v}" (expected "Fetch_All" or "Fetch_Specific")`);
    }
    return v;
}
function parseDestinationServiceEnv() {
    const url = process.env.DESTINATION_SERVICE_URL;
    const tokenUrl = process.env.DESTINATION_SERVICE_TOKEN_URL;
    const clientId = process.env.DESTINATION_SERVICE_CLIENT_ID;
    const clientSecret = process.env.DESTINATION_SERVICE_CLIENT_SECRET;
    const set = [url, tokenUrl, clientId, clientSecret];
    if (set.every((value) => value === undefined)) {
        return undefined;
    }
    if (url === undefined ||
        tokenUrl === undefined ||
        clientId === undefined ||
        clientSecret === undefined) {
        throw new Error("Incomplete DESTINATION_SERVICE_* environment configuration: DESTINATION_SERVICE_URL, " +
            "_TOKEN_URL, _CLIENT_ID and _CLIENT_SECRET must all be set together.");
    }
    return { url, tokenUrl, clientId, clientSecret };
}
/**
 * Loads and validates the environment.
 * @returns the typed, validated environment.
 * @throws {Error} if any required variable is invalid.
 */
export function loadEnv() {
    return {
        port: parsePort(process.env.PORT),
        nodeEnv: parseNodeEnv(process.env.NODE_ENV),
        logLevel: process.env.LOG_LEVEL,
        configDir: process.env.CONFIG_DIR ?? "config",
        destinationService: parseDestinationServiceEnv(),
        jmsQueueDiscoveryMode: parseQueueDiscoveryMode(process.env.JMS_QUEUE_DISCOVERY_MODE),
    };
}
/** The validated environment, resolved once at module load. */
export const env = loadEnv();
/**
 * Reads one tenant-scoped secret for `static` destination discovery (architecture: Authentication
 * Framework — "Credentials must come from configuration": the auth *strategy* lives in
 * `connectivity.json`'s `tenantAuth`; the actual secret value is environment-scoped like every other
 * credential in this codebase, and this is the one function that reads it).
 *
 * Convention: `CPI_<TENANTID>_<KEY>`, tenant id upper-cased with non-alphanumeric characters
 * replaced by `_` (e.g. tenant `primary`, key `CLIENT_SECRET` → `CPI_PRIMARY_CLIENT_SECRET`).
 * @param tenantId the tenant id (`tenants.json`).
 * @param key which credential to read.
 * @returns the secret value, or `undefined` when not set.
 */
export function getTenantCredential(tenantId, key) {
    const normalizedTenantId = tenantId.toUpperCase().replace(/[^A-Z0-9]/g, "_");
    return process.env[`CPI_${normalizedTenantId}_${key}`];
}
//# sourceMappingURL=env.js.map